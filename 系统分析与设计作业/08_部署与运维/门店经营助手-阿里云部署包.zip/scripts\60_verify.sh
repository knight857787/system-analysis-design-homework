#!/usr/bin/env bash
# 60 验收：15 项自动检查，全部通过才算部署完成
# 用法: bash 60_verify.sh [域名]
set -u

DOMAIN="${1:-oc-emporiumretai-ms.com}"
PORT="${PORT:-19870}"
SITE="/www/wwwroot/${DOMAIN}"
PASS=0
FAIL=0

line() { printf '%s\n' "------------------------------------------------------------"; }
run() {  # $1 描述  $2 命令（成功即通过）
  desc="$1"; shift
  if eval "$@" >/dev/null 2>&1; then
    PASS=$((PASS+1)); printf '  [PASS] %-46s\n' "$desc"
  else
    FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "$desc"
  fi
}
runq() {  # 输出值
  eval "$1" 2>/dev/null | head -n 1
}

line
printf '部署验收：%s\n' "$DOMAIN"
line

printf '\n【A. 进程与服务】\n'
run "systemd 服务 enabled"        "systemctl is-enabled --quiet store-assistant"
run "systemd 服务 active"         "systemctl is-active --quiet store-assistant"
run "本机端口 ${PORT} 监听"        "ss -lnt | grep -q ':${PORT} '"
printf '  服务启动时长: %s\n' "$(systemctl show store-assistant -p ActiveEnterTimestamp --value 2>/dev/null)"

printf '\n【B. 应用直连】\n'
run "应用 /api/health 返回 200"    "test \"\$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:${PORT}/api/health)\" = 200"
HEALTH="$(curl -s http://127.0.0.1:${PORT}/api/health || true)"
printf '  health: %s\n' "${HEALTH:-（空）}"
printf '%s' "$HEALTH" | grep -q '"database": *"ok"' && { PASS=$((PASS+1)); printf '  [PASS] %-46s\n' "数据库连接正常"; } || { FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "数据库连接异常"; }
run "首页 HTML 含站点标题"          "curl -s http://127.0.0.1:${PORT}/ | grep -q '<!DOCTYPE html'"
run "登录页可访问（SPA 外壳）"      "curl -s http://127.0.0.1:${PORT}/ | grep -q 'app.js'"

printf '\n【C. Nginx】\n'
run "nginx -t 语法通过"            "(nginx -t 2>&1 || /www/server/nginx/sbin/nginx -t 2>&1) | grep -q successful"
run "vhost 文件存在"               "test -f /www/server/panel/vhost/nginx/${DOMAIN}.conf"
run "80 端口对域名返回 301/308/200" "test \"\$(curl -s -o /dev/null -w '%{http_code}' -H 'Host: ${DOMAIN}' http://127.0.0.1/)\" != 000"
HTTP_CODE="$(curl -s -o /dev/null -w '%{http_code}' -H "Host: ${DOMAIN}" http://127.0.0.1/ || true)"
printf '  http://%s → HTTP %s\n' "$DOMAIN" "${HTTP_CODE:-000}"
if [ "${HTTP_CODE}" = "301" ] || [ "${HTTP_CODE}" = "308" ]; then
  PASS=$((PASS+1)); printf '  [PASS] %-46s\n' "HTTP 已跳转 HTTPS"
else
  FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "HTTP 未跳转 HTTPS（当前 ${HTTP_CODE}）"
fi

printf '\n【D. HTTPS 与证书】\n'
run "443 握手成功"                 "curl -sk -o /dev/null https://127.0.0.1/ -H 'Host: ${DOMAIN}'"
CERT="/www/server/panel/vhost/cert/${DOMAIN}/fullchain.pem"
if [ -f "$CERT" ]; then
  SUBJ="$(openssl x509 -in "$CERT" -noout -subject 2>/dev/null | head -n1)"
  DATES="$(openssl x509 -in "$CERT" -noout -dates 2>/dev/null | tr '\n' ' ')"
  printf '  证书主题: %s\n  有效期: %s\n' "$SUBJ" "$DATES"
  if printf '%s' "$SUBJ" | grep -q "$DOMAIN"; then
    PASS=$((PASS+1)); printf '  [PASS] %-46s\n' "证书域名匹配"
  else
    FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "证书域名不匹配（可能还是自签名，需申请正式证书）"
  fi
  if printf '%s' "$SUBJ" | grep -qi 'CN *= *'"$DOMAIN"; then :; fi
  openssl x509 -in "$CERT" -noout -checkend 0 >/dev/null 2>&1 && { PASS=$((PASS+1)); printf '  [PASS] %-46s\n' "证书未过期"; } || { FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "证书已过期"; }
else
  FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "证书文件不存在: $CERT"
fi

printf '\n【E. 公网链路（在本机执行 curl 走公网域名，需解析已生效）】\n'
PUB_HTTP="$(curl -s -o /dev/null -w '%{http_code}' --max-time 12 "https://${DOMAIN}/api/health" 2>/dev/null || true)"
printf '  https://%s/api/health → %s\n' "$DOMAIN" "${PUB_HTTP:-超时}"
if [ "${PUB_HTTP}" = "200" ]; then
  PASS=$((PASS+1)); printf '  [PASS] %-46s\n' "公网 HTTPS 可访问"
else
  FAIL=$((FAIL+1)); printf '  [FAIL] %-46s\n' "公网 HTTPS 不通（查 DNS、安全组、备案）"
fi

printf '\n【F. 数据与备份】\n'
run "数据库文件存在"                "test -f ${SITE}/data/store.db"
if [ -f "${SITE}/data/store.db" ]; then
  printf '  store.db 大小: %s  行数(SaleOrder): %s\n' \
    "$(du -h "${SITE}/data/store.db" | awk '{print $1}')" \
    "$(python3 - <<PY
import sqlite3
try:
    c=sqlite3.connect('${SITE}/data/store.db')
    print(c.execute('SELECT COUNT(*) FROM SaleOrder').fetchone()[0])
except Exception as e:
    print('err')
PY
)"
fi
run "备份脚本可执行"                "test -x $(dirname "$0")/70_backup.sh || test -f $(dirname "$0")/70_backup.sh"

printf '\n【G. 安全基线】\n'
run "密码已非默认 demo 口令"        "test -f /root/.oc_store_admin_rotated"
printf '  提示：/root/.oc_store_admin_rotated 由 rotate_password.py 生成\n'

line
printf '结果：通过 %d 项，失败 %d 项\n' "$PASS" "$FAIL"
line
if [ "$FAIL" -gt 0 ]; then
  printf '按顺序排查：\n'
  printf '  1) systemctl status store-assistant\n'
  printf '  2) journalctl -u store-assistant -n 80 --no-pager\n'
  printf '  3) tail -n 50 /www/wwwlogs/%s.error.log\n' "$DOMAIN"
  printf '  4) bash scripts/00_preflight.sh %s\n' "$DOMAIN"
  exit 1
fi
printf '全部通过。访问地址：https://%s\n' "$DOMAIN"
