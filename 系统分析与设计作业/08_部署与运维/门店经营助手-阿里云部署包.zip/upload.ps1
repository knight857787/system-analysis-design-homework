# upload.ps1 —— 在 Windows 侧把源码上传到服务器 /app/workspace
#
# 用法（在 PowerShell 中）：
#   .\upload.ps1 -HostName 101.201.222.69 -KeyPath "$env:USERPROFILE\.ssh\ecs_rsa"
#   .\upload.ps1 -HostName ... -KeyPath ... -Source "D:\...\作业\系统源代码"
#
# 为什么用 tar 而不是 Compress-Archive：
#   Windows PowerShell 5.1 的 Compress-Archive 会把路径写成反斜杠（server\core.py），
#   在 Linux 上解压后文件名里带字面反斜杠，目录结构全废（真实踩过：应用报
#   ModuleNotFoundError: No module named 'server'）。Windows 10+ 自带 bsdtar，
#   用 tar 打包能保证路径是正斜杠。

[CmdletBinding()]
param(
  [Parameter(Mandatory = $true)][string]$HostName,
  [string]$User = "root",
  [int]$Port = 22,
  [string]$KeyPath = "",
  [string]$Source = "D:\Deepseek Harness\系统分析与设计\作业\系统源代码",
  [string]$RemoteDir = "/app/workspace"
)

$ErrorActionPreference = "Stop"

if (-not (Test-Path $Source)) { throw "源码目录不存在: $Source" }
foreach ($cmd in @("tar", "scp", "ssh")) {
  if (-not (Get-Command $cmd -ErrorAction SilentlyContinue)) { throw "找不到 $cmd（Windows 10+ 自带 OpenSSH 与 tar）" }
}

$archive = Join-Path $env:TEMP ("store-app-" + (Get-Date -Format "yyyyMMdd-HHmmss") + ".tar.gz")
Write-Host "[1/4] 打包（tar，正斜杠路径）: $archive"
Push-Location $Source
try {
  & tar -czf $archive --exclude=__pycache__ --exclude="*.pyc" .
  if ($LASTEXITCODE -ne 0) { throw "tar 打包失败" }
} finally { Pop-Location }

$sshOpts = @()
if ($KeyPath) { $sshOpts += @("-i", $KeyPath) }
$target = "$User@$HostName"

Write-Host "[2/4] 上传到 $target:/tmp/app.tar.gz"
scp @sshOpts -o StrictHostKeyChecking=accept-new -P $Port $archive "${target}:/tmp/app.tar.gz"

Write-Host "[3/4] 服务器端解压到 $RemoteDir"
$remote = @"
set -eu
mkdir -p $RemoteDir
rm -rf $RemoteDir/* 2>/dev/null || true
tar -xzf /tmp/app.tar.gz -C $RemoteDir
find $RemoteDir -type d -name '__pycache__' -exec rm -rf {} + 2>/dev/null || true
rm -f /tmp/app.tar.gz
test -f $RemoteDir/run.py && echo 'run.py: ok' || { echo 'run.py: MISSING'; exit 1; }
echo "files=`$(find $RemoteDir -type f | wc -l)"
ls $RemoteDir
"@
$remote | ssh @sshOpts -o StrictHostKeyChecking=accept-new -p $Port $target "bash -s"

Write-Host "[4/4] 校验结果见上方输出"
Remove-Item $archive -Force
Write-Host "完成。下一步在服务器执行: bash /root/oc-deploy/scripts/20_deploy_app.sh $RemoteDir"
