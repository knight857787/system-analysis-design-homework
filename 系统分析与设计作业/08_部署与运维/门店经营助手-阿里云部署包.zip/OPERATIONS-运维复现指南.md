# 门店经营助手 · 运维复现指南

配套文档：[README-部署手册.md](./README-部署手册.md)（首次部署用）
适用：Alibaba Cloud Linux 4 + 宝塔面板 + Nginx + Python + SQLite

---

## 1. 链路一张图

```
用户浏览器 ──HTTPS(443)──► Nginx(宝塔) ──HTTP(127.0.0.1:19870)──► Python 应用(systemd)
                                  │                                        │
                             证书/静态/日志                           SQLite: data/store.db
                                                                           │
                                                                    backup/db/*.db（每日）
```

四条不变量，任何时候都不要破坏：

1. **应用只监听 127.0.0.1**，公网入口只有 Nginx；
2. **数据只在 `data/store.db`**，代码可以随便重发，数据目录不要在发布时动；
3. **配置以仓库里的 `conf/` 为准**，面板上的临时改动要在下次变更时同步回文件；
4. **每次发布前先打一个回滚点**（`80_release.sh` 自动做）。

---

## 2. 日常巡检

### 每天（2 分钟）

```bash
systemctl is-active store-assistant           # 期望 active
curl -s https://oc-emporiumretai-ms.com/api/health   # 期望 {"status":"up","database":"ok"}
tail -n 20 /var/log/oc-health.log             # 期望 recent local=200 public=200
df -h / | tail -1                             # 期望使用率 < 80%
```

### 每周（5 分钟）

```bash
# 错误日志里是否有 5xx
grep -c ' 50[0-9] ' /www/wwwlogs/oc-emporiumretai-ms.com.log
# 证书剩余天数
openssl x509 -in /www/server/panel/vhost/cert/oc-emporiumretai-ms.com/fullchain.pem -noout -enddate
# 备份是否在产出
ls -lh /www/wwwroot/oc-emporiumretai-ms.com/backup/db | tail -3
# 磁盘与内存
du -sh /www/wwwroot/oc-emporiumretai-ms.com/* | sort -h
free -m | head -2
```

### 每月（15 分钟）

```bash
# 1) 恢复演练（在临时目录验证备份可用，不动生产数据）
TMP=$(mktemp -d)
LATEST=$(ls -t /www/wwwroot/oc-emporiumretai-ms.com/backup/db/*.db | head -1)
python3 - "$LATEST" "$TMP/store.db" <<'PY'
import sqlite3, sys
with sqlite3.connect(sys.argv[1]) as s, sqlite3.connect(sys.argv[2]) as d:
    s.backup(d)
c = sqlite3.connect(sys.argv[2])
print('tables=', c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0])
print('sale_orders=', c.execute('SELECT COUNT(*) FROM SaleOrder').fetchone()[0])
PY
rm -rf "$TMP"

# 2) 依赖与系统更新（先在低峰期，且先看更新内容）
dnf check-update | head -20

# 3) 检查有没有陌生人尝试登录
lastb 2>/dev/null | head -10
grep 'Failed password' /var/log/secure | tail -10
```

---

## 3. 发布流程（改代码后）

```bash
# 0) 本地改完、Windows 上自测通过后，上传新源码到 /app/workspace
# 1) 发布会自动：打包当前版本 → rsync → 重启 → 健康检查（失败自动回滚）
cd /root/oc-deploy
bash scripts/80_release.sh /app/workspace
```

**期望**：

```
1) 打包当前版本做回滚点
  [OK]   /www/wwwroot/.../backup/releases/app-20261118-131500.tar.gz
2) 同步新代码
  [OK]   代码已更新
3) 重启并验收
  health: HTTP 200 {"ok": true, ...}
  [OK]   发布成功。回滚命令： bash 80_rollback.sh 20261118-131500
```

发布窗口建议：门店闭店后（21:00 之后）。发布后 5 分钟内人会盯着 `/var/log/oc-health.log`。

**回滚**：

```bash
bash scripts/80_release.sh rollback 20261118-131500
```

回滚只换代码，不换数据库；如果新版本改过库结构，需要配合 `71_restore.sh` 回滚数据。

---

## 4. 备份、恢复与演练

| 项 | 当前策略 |
|---|---|
| 备份内容 | SQLite 在线备份（`store.db`）+ Nginx vhost/unit/凭据快照 + MySQL 预留库 dump |
| 频率 | 每日 02:30（cron） |
| 保留 | 30 天（`--keep 30`） |
| 位置 | `/www/wwwroot/<域名>/backup/{db,conf}` |
| 一致性 | 用 SQLite Backup API，WAL 模式下也不会备份出半截数据 |
| RPO | ≤ 24 小时（可改每小时） |
| RTO | 约 3 分钟（stop → 覆盖 → start → 健康检查） |

**恢复**：

```bash
bash scripts/71_restore.sh /www/wwwroot/oc-emporiumretai-ms.com/backup/db/store-20261118-023000.db
# 需要输入 RESTORE 确认；当前库会自动留成 store.db.pre-restore.<时间戳>
```

**异地备份（建议加）**：阿里云 OSS

```bash
# 安装 ossutil 后，每天备份完推一份到 OSS
ossutil cp -r /www/wwwroot/oc-emporiumretai-ms.com/backup/db/ oss://<bucket>/oc-store/ -u
```

---

## 5. 证书与域名

| 场景 | 操作 |
|---|---|
| 查看到期 | `openssl x509 -in /www/server/panel/vhost/cert/<域名>/fullchain.pem -noout -enddate` |
| 面板证书续期 | 宝塔 → 网站 → SSL → Let's Encrypt，到期前 30 天自动续；也可手动点「续签」 |
| certbot 续期 | `certbot renew --dry-run` 验证，正式 `certbot renew`；timer 一般已自动装好 |
| 手工证书 | 到期前重新下载 → `bash scripts/40_ssl.sh --manual /root/alicert` |
| 续期后 | 一定要 `nginx -t && systemctl reload nginx`（脚本已内置） |
| 换域名 | 改 vhost 的 `server_name`、证书路径、`SITE` 变量，再跑 30/40 两步 |
| DNS 变更 | 阿里云 DNS 改 A 记录 → `dig +short <域名>` 确认 → 等 TTL 生效再申请证书 |

> HSTS 打开后（vhost 里那行注释）浏览器会强制 HTTPS 半年。**只在确认续期正常后再开**，否则证书过期时用户连降级都进不去。

---

## 6. MySQL 配套库：定位、同步与迁移路径

**已确认的部署决策：业务读写用 SQLite，MySQL 作为配套报表库。** 两者分工：

| | SQLite（`data/store.db`） | MySQL（`oc_store`） |
|---|---|---|
| 角色 | **唯一业务数据源**，应用直接读写 | **报表副本**，只读查询，供 BI / 课程演示 / 外部工具 |
| 表 | 41 张业务表 + 4 视图 | 4 张汇总表：`daily_sales`、`product_stock`、`credit_outstanding`、`sync_log` |
| 写入方 | 应用（systemd 服务） | `55_mysql_sync.sh`（每日 03:10 或手动） |
| 备份 | `70_backup.sh`（SQLite 在线备份） | 同脚本附带 `mysqldump` |
| 恢复 | `71_restore.sh` | 用 dump 文件 `mysql < xxx.sql` |

### 6.1 日常使用

```bash
# 手动同步一次（幂等，可随时跑）
bash scripts/55_mysql_sync.sh

# 只看将执行的 SQL
bash scripts/55_mysql_sync.sh --dry-run

# 查报表
mysql --defaults-extra-file=/root/.oc_store_mysql_tool.cnf -e \
  "USE oc_store; SELECT * FROM daily_sales ORDER BY sale_date DESC LIMIT 7;"
mysql --defaults-extra-file=/root/.oc_store_mysql_tool.cnf -e \
  "USE oc_store; SELECT product_name, qty, cost_value FROM product_stock ORDER BY cost_value DESC LIMIT 10;"
mysql --defaults-extra-file=/root/.oc_store_mysql_tool.cnf -e \
  "USE oc_store; SELECT customer_name, outstanding, overdue_days FROM credit_outstanding WHERE outstanding>0 ORDER BY overdue_days DESC;"
```

日志：`/var/log/oc-mysql-sync.log`；每次同步的行数也会写进 `sync_log` 表，便于核对"同步到底跑没跑"。

### 6.2 如果以后要求业务数据进 MySQL

不是改个连接串就行，按这个顺序做，别一次性全改：

| 步骤 | 内容 | 工作量 |
|---|---|---|
| 1 | 写 `db_mysql.py`，用 `pymysql` 实现与 `db.py` 同接口（`query/query_one/scalar/execute/insert`） | 0.5 天 |
| 2 | `schema.sql` 转 MySQL DDL（`AUTOINCREMENT→AUTO_INCREMENT`、`datetime('now','localtime')→NOW()`、`REAL→DECIMAL`） | 0.5 天 |
| 3 | 4 个视图改写成 MySQL 语法（`julianday()` 全部替换） | 0.3 天 |
| 4 | 业务 SQL 里的 SQLite 专有函数做兼容层（`GROUP_CONCAT`、`INSERT OR REPLACE`、`PRAGMA`） | 0.5 天 |
| 5 | 数据迁移脚本（逐表 INSERT，自增 ID 对齐） | 0.3 天 |
| 6 | 全量回归：17 项接口 + 16 页渲染 + 收银/收货/对账/盘点四流程 | 0.5 天 |

合计约 **2 人日**，其中回归测试占一半。建议在低峰期做，且先双跑（应用写 MySQL，同时保留 SQLite 备份）。

---

## 7. 安全加固清单（按性价比排序）

| # | 措施 | 命令/操作 | 风险提示 |
|---|---|---|---|
| 1 | 换掉演示口令 | `rotate_password.py --all` | 必做，否则等于公开后台 |
| 2 | 改宝塔面板端口 + 安全入口 | 面板 → 设置 → 面板端口/安全入口 | 改完先记住新地址，别把自己锁外面 |
| 3 | 宝塔面板开 2FA + 面板 SSL | 面板 → 设置 → 双重验证 | — |
| 4 | SSH 禁止密码登录 | `/etc/ssh/sshd_config`：`PasswordAuthentication no` | **先确认密钥能登录**，再重启 sshd |
| 5 | 装 fail2ban 防爆破 | `dnf install -y fail2ban && systemctl enable --now fail2ban` | 自己别被误封白名单 |
| 6 | 云安全组最小化 | 只放 22/80/443，22 限制来源 IP | 需要固定办公 IP |
| 7 | 登录限流 | 启用 vhost 里的 `limit_req` 段 | `nginx -t` 通过后再 reload |
| 8 | 关闭目录浏览与隐藏文件 | vhost 已含 `location ~ /\.` deny | — |
| 9 | 定期改口令 | 每季度 `rotate_password.py --all` | 改完重启服务 |
| 10 | 日志留存 ≥ 6 个月 | 宝塔 → 日志 或 logrotate | 备案/监管检查常要 |

---

## 8. 监控与告警（最小可用）

1. **本机巡检**：`90_healthcheck.sh` 每 5 分钟跑一次，不通自动重启并写 `/var/log/oc-health.log`；
2. **外部探活**：UptimeRobot / 阿里云云监控，URL 填 `https://<域名>/api/health`，断言 HTTP 200 且响应含 `"database":"ok"`，间隔 5 分钟，告警到邮箱/钉钉；
3. **磁盘告警**：云监控看 `/` 使用率，阈值 80%；
4. **证书告警**：`openssl ... -enddate` 剩余 < 15 天时提醒（可塞进 healthcheck）。

---

## 9. 容量与性能

- 应用是 `ThreadingHTTPServer`，每请求一线程；单店场景（同时在店 2～3 人、线上单几个）完全够用。
- 粗略压测：

```bash
# 首页
ab -n 500 -c 20 https://oc-emporiumretai-ms.com/            # 关注 Requests per second 与 Failed requests
# 接口
ab -n 500 -c 20 https://oc-emporiumretai-ms.com/api/health
```

  参考预期（1 核 2G）：静态首页 ≥ 200 req/s，接口 ≥ 100 req/s；若失败率高，看 `journalctl` 是否线程耗尽、`ulimit -n` 是否过小（unit 已设 `LimitNOFILE=4096`）。

- 真实瓶颈通常是 **SQLite 单写者**：并发收银时写入会排队。单店一天 50～100 单，无感。
- 扩容路径（按顺序）：① Nginx 加 `gzip` 与静态缓存（已开 gzip）；② 静态资源改由 Nginx 直出（vhost 注释里有现成写法）；③ 起多实例（19870/19871）+ Nginx upstream 轮询（注意 SQLite 无法多写，需先把库换掉）；④ 换 MySQL + gunicorn。

---

## 10. 应急处理（按现象查）

| 现象 | 5 分钟内怎么做 | 之后 |
|---|---|---|
| 502 | `systemctl restart store-assistant`；仍 502 → `getsebool httpd_can_network_connect` | 若为 SELinux，`setsebool -P` 并写进变更记录 |
| 500 | `journalctl -u store-assistant -n 80` | 按报错修代码或用 `80_release.sh rollback <上一版>` |
| 全站打不开 | 面板看 Nginx 是否运行；阿里云看实例是否在运行；`dig` 看解析 | 按「应用→Nginx→安全组→DNS」顺序排除 |
| 证书过期 | `bash scripts/40_ssl.sh --certbot` 应急签发 | 修好自动续期（见第 5 节） |
| 数据被误删/改坏 | 立刻停服务避免覆盖 → `71_restore.sh <最近备份>` | 复盘：谁、哪一步、是否缺二次确认 |
| 磁盘满 | `du -sh /www/wwwlogs/* \| sort -h \| tail`；清旧日志与旧备份 | 加 logrotate、调小 `--keep` |
| 疑似被入侵 | 断公网（安全组只留 22 且改源 IP）→ 保留现场（`tar` 日志）→ 改全部口令 → 从备份重建 | 走第 7 节加固清单 |

**变更纪律**：任何线上操作前，先 `bash scripts/70_backup.sh`（10 秒），再动手。这是最便宜的安全带。

---

## 11. 从零复现（换服务器时照这个走，约 30 分钟）

```bash
# 1) 新机体检
bash scripts/00_preflight.sh <域名>
# 2) 环境（装 python/放行端口/SELinux）
bash scripts/10_runtime.sh
# 3) 上传源码到 /app/workspace（Windows 侧 upload.ps1）
# 4) 应用
bash scripts/20_deploy_app.sh /app/workspace <域名>
# 5) Nginx
bash scripts/30_nginx.sh <域名>
# 6) 证书
bash scripts/40_ssl.sh --bt
# 7) MySQL（可选，按要求）
MYSQL_ROOT_PASSWORD='***' bash scripts/50_mysql.sh
bash scripts/55_mysql_sync.sh
# 8) 换口令
cd /www/wwwroot/<域名>/app && sudo -u www env STORE_DATA_DIR=/www/wwwroot/<域名>/data \
  /usr/bin/python3.11 /root/oc-deploy/scripts/rotate_password.py --all
# 9) 验收
bash scripts/60_verify.sh <域名>
# 10) 定时任务
crontab -e   # 备份 + 巡检两行
```

需要带数据迁移时：从旧机 `70_backup.sh` → 拷 `store-*.db` 到新机 → `71_restore.sh`。

---

## 12. 命令速查表

```bash
# 状态
systemctl status store-assistant
journalctl -u store-assistant -n 100 -f
tail -f /www/wwwlogs/oc-emporiumretai-ms.com.error.log

# 应用
curl -s http://127.0.0.1:19870/api/health
ss -lntp | grep -E ':(80|443|19870)'

# Nginx
nginx -t
nginx -s reload
systemctl status nginx

# 证书
openssl s_client -connect oc-emporiumretai-ms.com:443 -servername oc-emporiumretai-ms.com </dev/null 2>/dev/null | openssl x509 -noout -subject -dates

# 数据
ls -lh /www/wwwroot/oc-emporiumretai-ms.com/data
bash /root/oc-deploy/scripts/70_backup.sh
bash /root/oc-deploy/scripts/71_restore.sh <备份文件>

# 发布/回滚
bash /root/oc-deploy/scripts/80_release.sh /app/workspace
bash /root/oc-deploy/scripts/80_release.sh rollback <时间戳>

# 验收
bash /root/oc-deploy/scripts/60_verify.sh
```

---

## 13. 变更记录模板（每次上线复制一份）

```
日期：2026-__-__
变更人：
变更内容：（一句话）
回滚点：backup/releases/app-<时间戳>.tar.gz
影响范围：（接口/页面/数据库）
验证方式：（verify.sh 结果 + 手工点了哪几个页面）
异常与处理：
```

---

**边界声明**：以上流程与参数针对本项目的单店部署；脚本未在你的 ECS 上实跑过（本机拿不到该实例登录入口）。执行中任何一步输出与"期望"不符，把输出发给我，我按实际报错改脚本或改配置，而不是让你硬试。
