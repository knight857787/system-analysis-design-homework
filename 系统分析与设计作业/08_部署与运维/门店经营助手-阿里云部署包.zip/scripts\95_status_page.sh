#!/bin/bash
# 95 生成运维状态页（静态 HTML），给 dsh.<域名> 用；只读，不碰业务数据
# cron: */5 * * * * /bin/bash /root/oc-deploy/scripts/95_status_page.sh
set -u
DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
OUT_DIR="${OUT_DIR:-/www/wwwroot/dsh.${DOMAIN}}"
OUT="${OUT_DIR}/index.html"
PORT="${PORT:-19870}"

mkdir -p "$OUT_DIR"

health_json="$(curl -s --max-time 3 "http://127.0.0.1:${PORT}/api/health" 2>/dev/null || echo '{}')"
health_ok="否"
printf '%s' "$health_json" | grep -q '"status": *"up"' && health_ok="是"

svc_app="$(systemctl is-active store-assistant 2>/dev/null || echo unknown)"
svc_web="$(systemctl is-active nginx 2>/dev/null || echo unknown)"
svc_db="$(systemctl is-active mysqld 2>/dev/null || echo unknown)"

cert="${CERT_FILE:-/etc/nginx/ssl/${DOMAIN}/fullchain.pem}"
cert_days="n/a"
if [ -f "$cert" ]; then
  end=$(openssl x509 -in "$cert" -noout -enddate 2>/dev/null | cut -d= -f2)
  if [ -n "$end" ]; then
    cert_days=$(( ( $(date -d "$end" +%s) - $(date +%s) ) / 86400 ))
  fi
fi

last_backup="无"
if [ -d "${SITE}/backup/db" ]; then
  f=$(ls -t "${SITE}/backup/db"/*.db 2>/dev/null | head -1)
  [ -n "$f" ] && last_backup="$(basename "$f") ($(du -h "$f" | awk '{print $1}'))"
fi

db_rows="n/a"
if [ -x /usr/bin/mysql ] && [ -f /root/.oc_store_mysql_tool.cnf ]; then
  db_rows=$(/usr/bin/mysql --defaults-extra-file=/root/.oc_store_mysql_tool.cnf -N -B \
    -e "SELECT CONCAT(daily_sales,'/',product_stock,'/',credit_outstanding) FROM (
          SELECT (SELECT COUNT(*) FROM oc_store.daily_sales) daily_sales,
                 (SELECT COUNT(*) FROM oc_store.product_stock) product_stock,
                 (SELECT COUNT(*) FROM oc_store.credit_outstanding) credit_outstanding) t;" 2>/dev/null || echo n/a)
fi

disk="$(df -h / | awk 'NR==2{print $3" / "$2" ("$5")"}')"
load="$(cut -d' ' -f1-3 /proc/loadavg)"
now="$(date '+%Y-%m-%d %H:%M:%S %Z')"
uptime_app="$(systemctl show store-assistant -p ActiveEnterTimestamp --value 2>/dev/null | cut -d' ' -f2-3)"

cat > "$OUT" <<HTML
<!DOCTYPE html>
<html lang="zh-CN"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>运维状态 · ${DOMAIN}</title>
<style>
:root{--b:#1f2937;--m:#6b7280;--g:#0f9d58;--r:#d93025}
*{box-sizing:border-box}
body{margin:0;padding:32px;font:14px/1.6 -apple-system,"Segoe UI","Microsoft YaHei",sans-serif;color:var(--b);background:#f8fafc}
.wrap{max-width:760px;margin:0 auto}
h1{font-size:20px;margin:0 0 4px}
.sub{color:var(--m);font-size:13px;margin-bottom:24px}
.card{background:#fff;border:1px solid #e5e7eb;border-radius:10px;overflow:hidden}
table{width:100%;border-collapse:collapse}
th,td{padding:10px 16px;text-align:left;border-bottom:1px solid #f1f3f5;font-size:13.5px}
th{width:190px;color:var(--m);font-weight:500;background:#fcfcfd}
tr:last-child td,tr:last-child th{border-bottom:0}
.ok{color:var(--g);font-weight:600}.bad{color:var(--r);font-weight:600}
.foot{margin-top:16px;color:var(--m);font-size:12px}
a{color:#2563eb;text-decoration:none}
</style></head><body><div class="wrap">
<h1>门店经营助手 · 运维状态</h1>
<div class="sub">dsh.${DOMAIN} · 只读速览（每 5 分钟刷新）</div>
<div class="card"><table>
<tr><th>生成时间</th><td>${now}</td></tr>
<tr><th>业务站点</th><td><a href="https://${DOMAIN}/" target="_blank">https://${DOMAIN}</a></td></tr>
<tr><th>应用健康</th><td class="$([ "$health_ok" = "是" ] && echo ok || echo bad)">${health_ok}　<code>${health_json:0:120}</code></td></tr>
<tr><th>服务状态</th><td>store-assistant <b class="$([ "$svc_app" = "active" ] && echo ok || echo bad)">${svc_app}</b> · nginx <b class="$([ "$svc_web" = "active" ] && echo ok || echo bad)">${svc_web}</b> · mysqld <b class="$([ "$svc_db" = "active" ] && echo ok || echo bad)">${svc_db}</b></td></tr>
<tr><th>应用启动于</th><td>${uptime_app:-n/a}</td></tr>
<tr><th>TLS 证书剩余</th><td class="$([ "${cert_days:-0}" -gt 20 ] 2>/dev/null && echo ok || echo bad)">${cert_days} 天</td></tr>
<tr><th>最近备份</th><td>${last_backup}</td></tr>
<tr><th>MySQL 报表行数</th><td>daily/product/credit = ${db_rows}</td></tr>
<tr><th>磁盘 / 负载</th><td>${disk} · load ${load}</td></tr>
</table></div>
<div class="foot">数据由 <code>/root/oc-deploy/scripts/95_status_page.sh</code> 生成；页面本身不含业务数据。</div>
</div></body></html>
HTML

chmod 644 "$OUT"
echo "status page -> $OUT"
