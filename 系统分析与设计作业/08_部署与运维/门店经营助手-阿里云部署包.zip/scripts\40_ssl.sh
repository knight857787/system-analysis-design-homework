#!/usr/bin/env bash
# 40 HTTPS 证书（三条路径：宝塔面板 / certbot / 手动上传阿里云证书）
# 用法:
#   bash 40_ssl.sh --bt                  # 打印宝塔面板操作步骤（最简单，推荐）
#   bash 40_ssl.sh --certbot             # 用 certbot webroot 申请 Let's Encrypt
#   bash 40_ssl.sh --manual /root/cert   # 从目录导入阿里云下载的 nginx 格式证书
# 默认（无参数）打印菜单并退出，不会做任何修改。
set -eu

DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
CERT_DIR="/www/server/panel/vhost/cert/${DOMAIN}"
NGINX_BIN="$(command -v nginx || echo /www/server/nginx/sbin/nginx)"
MODE="${1:-menu}"

line() { printf '%s\n' "------------------------------------------------------------"; }
step() { printf '\n>> %s\n' "$1"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
warn() { printf '  [WARN] %s\n' "$1"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

reload_nginx() {
  if systemctl is-active --quiet nginx 2>/dev/null; then systemctl reload nginx; else "$NGINX_BIN" -s reload; fi
  "$NGINX_BIN" -t >/dev/null 2>&1 && ok "nginx 配置仍合法并已重载" || die "重载后 nginx -t 失败"
}

case "$MODE" in
  --bt)
    line
    printf '宝塔面板申请免费证书（推荐，自动续期）\n'
    line
    cat <<'TXT'
  1. 浏览器登录宝塔面板 → 左侧「网站」→ 找到 oc-emporiumretai-ms.com
  2. 点站点右侧「设置」→ 顶部「SSL」→ 选「Let's Encrypt」
  3. 勾选两个域名（oc-emporiumretai-ms.com、www.oc-emporiumretai-ms.com）
  4. 验证方式选「文件验证」，点「申请」，约 10~60 秒出证书
  5. 申请成功后把「强制 HTTPS」打开（本部署包的 vhost 已在 80 做 301，二者等效）
  6. 宝塔会自动写入 /www/server/panel/vhost/cert/<域名>/ 并配置续期定时任务

  前置条件（缺一不可）：
    - 域名 A 记录已指向服务器公网 IP（@ 与 www 都要）
    - 阿里云安全组放行 80、443
    - 本机 firewalld 放行 80、443（10_runtime.sh 已处理）
    - 备案已完成（未备案时 80/443 会被拦截，证书申请必然失败）

  申请失败最常见原因：80 端口没放行 / 域名没解析对 / 有 CDN 或 WAF 拦住了
  /.well-known/acme-challenge/ 路径。
TXT
    ;;

  --certbot)
    line
    printf '用 certbot 申请 Let's Encrypt（不依赖宝塔面板）\n'
    line
    step "1) 检查 80 端口与解析"
    curl -s -o /dev/null -w '  http://%{http_code}  ' "http://${DOMAIN}/.well-known/acme-challenge/ping" || true
    printf '\n'
    warn "若上面不是 404/403 而是超时，先修好 80 端口再继续"

    step "2) 安装 certbot"
    if command -v certbot >/dev/null 2>&1; then ok "certbot 已安装"; else
      printf '  即将执行: dnf install -y certbot（是否继续? [y/N] ）'
      read -r ans
      case "$ans" in y|Y) dnf install -y certbot ;; *) die "已取消" ;; esac
    fi

    step "3) 准备 webroot"
    mkdir -p "/www/wwwroot/${DOMAIN}/.well-known/acme-challenge"
    if id www >/dev/null 2>&1; then chown -R www:www "/www/wwwroot/${DOMAIN}/.well-known"; fi
    ok "webroot 就绪"

    step "4) 申请证书"
    certbot certonly --webroot -w "/www/wwwroot/${DOMAIN}" \
      -d "${DOMAIN}" -d "www.${DOMAIN}" \
      --email "admin@${DOMAIN}" --agree-tos --non-interactive \
      --deploy-hook "cp -f /etc/letsencrypt/live/${DOMAIN}/fullchain.pem ${CERT_DIR}/fullchain.pem && cp -f /etc/letsencrypt/live/${DOMAIN}/privkey.pem ${CERT_DIR}/privkey.pem && chmod 644 ${CERT_DIR}/fullchain.pem && chmod 600 ${CERT_DIR}/privkey.pem && systemctl reload nginx"
    ok "证书已签发并复制到 ${CERT_DIR}"

    step "5) 续期检查"
    certbot renew --dry-run 2>&1 | tail -n 5 | sed 's/^/  /' || warn "dry-run 失败，检查 80 端口与 webroot 路径"
    printf '\n  自动续期来源（任意一个存在即可）：\n'
    systemctl list-timers 2>/dev/null | grep -i certbot | sed 's/^/  /' || printf '  （未见 certbot timer）\n'
    [ -f /etc/cron.d/certbot ] && ok "/etc/cron.d/certbot 存在" || printf '  如无 timer，添加 cron：0 3 * * * certbot renew --quiet\n'
    reload_nginx
    ;;

  --manual)
    SRC="${2:-}"
    line
    printf '导入阿里云下载的证书（nginx 格式）\n'
    line
    [ -n "$SRC" ] || die "用法: bash 40_ssl.sh --manual /path/to/cert_dir"
    [ -d "$SRC" ] || die "目录不存在: $SRC"
    CRTFILE="$(find "$SRC" -maxdepth 1 -name '*.pem' ! -name '*key*' | head -n1 || true)"
    KEYFILE="$(find "$SRC" -maxdepth 1 -name '*key*.pem' | head -n1 || true)"
    [ -n "$CRTFILE" ] || die "目录里找不到证书 pem 文件"
    [ -n "$KEYFILE" ] || die "目录里找不到私钥 pem 文件"
    cp -f "$CRTFILE" "${CERT_DIR}/fullchain.pem"
    cp -f "$KEYFILE" "${CERT_DIR}/privkey.pem"
    chmod 644 "${CERT_DIR}/fullchain.pem"
    chmod 600 "${CERT_DIR}/privkey.pem"
    ok "已导入: $(basename "$CRTFILE") / $(basename "$KEYFILE")"
    "$NGINX_BIN" -t >/dev/null 2>&1 && reload_nginx || die "nginx -t 失败，检查证书与私钥是否配套"
    printf '\n  域名与证书是否匹配：\n'
    openssl x509 -in "${CERT_DIR}/fullchain.pem" -noout -subject -dates 2>/dev/null | sed 's/^/  /'
    warn "手工证书不会自动续期，到期前 30 天需重新下载导入"
    ;;

  *)
    line
    printf '选择证书方式（当前未做任何修改）\n'
    line
    cat <<TXT
  A. bash 40_ssl.sh --bt
     宝塔面板一键 Let's Encrypt —— 最简单，自动续期（推荐）

  B. bash 40_ssl.sh --certbot
     命令行 certbot 申请 —— 适合面板 SSL 页面报错时兜底

  C. bash 40_ssl.sh --manual /root/alicert
     阿里云控制台下载 nginx 格式证书后导入 —— 适合免费证书额度用完时兜底

  三条路径最终都落在同一个位置：
     ${CERT_DIR}/fullchain.pem
     ${CERT_DIR}/privkey.pem
  因此切换到任意一种都不需要再改 Nginx 配置。
TXT
    ;;
esac
