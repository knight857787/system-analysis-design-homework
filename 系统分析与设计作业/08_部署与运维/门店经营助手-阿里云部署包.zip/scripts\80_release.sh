#!/usr/bin/env bash
# 80 发布与回滚：发布前自动打包当前版本；出问题时一键回到上一个版本
# 用法:
#   bash 80_release.sh [源码目录]        # 打包当前 APP → rsync 新源码 → 重启 → 验收
#   bash 80_rollback.sh <时间戳>         # 回到某个历史版本
set -eu

DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
APP="${SITE}/app"
REL="${SITE}/backup/releases"
TS="$(date +%Y%m%d-%H%M%S)"

line() { printf '%s\n' "------------------------------------------------------------"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

MODE="${1:-release}"

line

if [ "$MODE" = "rollback" ]; then
  WANT="${2:-}"
  [ -n "$WANT" ] || die "用法: bash 80_rollback.sh <时间戳，如 20261118-131500>"
  TARBALL="${REL}/app-${WANT}.tar.gz"
  [ -f "$TARBALL" ] || die "找不到版本包: $TARBALL（可用 ls ${REL} 查看）"
  printf '回滚到 %s\n' "$WANT"
  systemctl stop store-assistant
  rm -rf "${APP}.rollback-old"
  mv "$APP" "${APP}.rollback-old"
  mkdir -p "$APP"
  tar -xzf "$TARBALL" -C "$APP"
  chown -R www:www "$APP"
  systemctl start store-assistant
  sleep 2
  CODE="$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:19870/api/health || true)"
  [ "$CODE" = "200" ] && ok "回滚完成（旧版本留在 ${APP}.rollback-old，确认无误后可删）" || die "回滚后不健康，检查日志"
  exit 0
fi

SRC="${2:-/app/workspace}"
printf '发布新版本（源码: %s）\n' "$SRC"
[ -d "$SRC" ] || die "源码目录不存在"
[ -f "$SRC/run.py" ] || { [ -f "$SRC/系统源代码/run.py" ] && SRC="$SRC/系统源代码"; }
[ -f "$SRC/run.py" ] || die "源码里没有 run.py"

mkdir -p "$REL"
printf '1) 打包当前版本做回滚点\n'
if [ -d "$APP" ] && [ -n "$(ls -A "$APP" 2>/dev/null)" ]; then
  tar -czf "${REL}/app-${TS}.tar.gz" -C "$APP" --exclude='data' .
  ok "${REL}/app-${TS}.tar.gz"
else
  printf '  （首次发布，无可回滚版本）\n'
fi

printf '2) 同步新代码\n'
rsync -a --delete --exclude 'data/' --exclude '__pycache__/' --exclude '*.pyc' "${SRC}/" "${APP}/"
chown -R www:www "$APP"
ok "代码已更新"

printf '3) 重启并验收\n'
systemctl restart store-assistant
sleep 2
CODE="$(curl -s -o /tmp/_r.json -w '%{http_code}' http://127.0.0.1:19870/api/health || true)"
printf '  health: HTTP %s %s\n' "$CODE" "$(cat /tmp/_r.json 2>/dev/null || true)"
if [ "$CODE" = "200" ]; then
  ok "发布成功。回滚命令： bash 80_rollback.sh ${TS}"
else
  printf '  [FAIL] 新版本不健康，自动回滚...\n'
  bash "$0" rollback "$TS"
fi
