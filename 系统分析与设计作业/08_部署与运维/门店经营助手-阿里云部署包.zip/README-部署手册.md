# 门店经营助手 · 阿里云 ECS + 宝塔面板部署手册

> 目标：把 `/app/workspace` 里的网页程序部署到 **oc-emporiumretai-ms.com**，走 Nginx 反向代理，开启 HTTPS，并留下可复现的运维脚本。
>
> 环境：Alibaba Cloud Linux 4 + 宝塔面板 + Nginx + Python 3.10+ + SQLite（应用数据）+ MySQL（按部署要求创建的配套库）

**已确认的两项决策**（2026-11-18）：
1. **保留 SQLite 作为业务数据源上线**，MySQL 作为配套报表库（每日同步 4 张汇总表，见第 7 节）；
2. 上线前必须换掉演示口令（见第 8 节），并在页脚展示 ICP 备案号。

> ⚠️ **实际部署与本手册的差异**：目标服务器（`101.201.222.69`）**并没有预装宝塔面板**，
> 因此本次采用"dnf 安装 Nginx + acme.sh 申请 Let's Encrypt"的等价路径，站点已于 2026-11-18 上线：
> **https://oc-emporiumretai-ms.com**。
> 实际执行的完整命令、版本号、踩坑与验收结果见 **[本次部署记录-2026-11-18.md](./本次部署记录-2026-11-18.md)**。
> 本手册仍按宝塔写法保留，作为"有面板环境"的参考路径。

---

## 0. 开口之前：四个前置条件（缺一个都会卡住）

| 前置 | 判定方法 | 不满足的表现 |
|---|---|---|
| 域名 A 记录已指向 ECS 公网 IP | `getent hosts oc-emporiumretai-ms.com` 返回你的 ECS IP | 证书申请失败、浏览器打不开 |
| 阿里云安全组放行 22/80/443 | 控制台 → 实例 → 安全组 → 入方向 | 外网连不上、HTTPS 超时 |
| 备案已完成且接入阿里云 | 阿里云备案控制台显示「已备案」 | 80/443 被运营商侧拦截 |
| 宝塔已装 Nginx（推荐 1.20+） | 宝塔 → 软件商店 → Nginx 已安装 | vhost 目录不存在 |

> 备案号需要在网站页脚展示（工信部要求）。部署完成后建议在页面页脚加上
> `陕ICP备XXXXXXXX号` 并链接 `https://beian.miit.gov.cn`。

---

## 1. 连接服务器并体检

```bash
# 在你自己的电脑上（Windows 自带 OpenSSH）
ssh -i ~/.ssh/ecs_rsa root@<ECS公网IP>
```

登录后在服务器上执行：

```bash
# 上传部署包（若还没有）
mkdir -p /root/oc-deploy
# 把本目录（部署包-阿里云宝塔）里的 conf/ scripts/ 传上去，例如用 WinSCP 拖拽

cd /root/oc-deploy
bash scripts/00_preflight.sh oc-emporiumretai-ms.com
```

**期望输出**（关键行）：

```
1) 系统与内核
  Alibaba Cloud Linux 4.x  内核 5.10.x
2) Python
  版本 3.11           ← 必须 >= 3.10
3) 宝塔面板
  [OK] /www/server/panel 存在
  [OK] 面板自带 nginx: nginx version: nginx/1.24.x
4) 端口占用
  [OK] 端口 80 空闲   [OK] 端口 443 空闲   [OK] 端口 19870 空闲
```

出现 `[FAIL] 低于 3.10` → 先跑第 3 步；出现端口被占用 → 先查 `ss -lntp | grep :80`。

---

## 2. 上传源码到 /app/workspace

两种方式，任选其一。

**方式 A：Windows 一键（推荐）**

```powershell
cd "D:\Deepseek Harness\系统分析与设计\部署包-阿里云宝塔"
.\upload.ps1 -HostName <ECS公网IP> -KeyPath "$env:USERPROFILE\.ssh\ecs_rsa"
```

> ⚠️ **踩过的坑**：不要用 PowerShell 的 `Compress-Archive` 打包再上传。
> 它会把路径写成反斜杠（`server\core.py`），Linux 解压后文件名里带**字面反斜杠**，目录结构全废，
> 应用会报 `ModuleNotFoundError: No module named 'server'`。
> 本包的 `upload.ps1` 已改用 Windows 自带的 `tar`（bsdtar），路径是正斜杠，可放心用。

**方式 B：服务器侧手动**

```bash
mkdir -p /app/workspace
# 用 WinSCP / scp 把「作业/系统源代码」里的内容传进 /app/workspace
ls /app/workspace
# 期望看到: run.py  server/  web/  data/  （data 里是 store.db）
```

> 如果你的 `/app/workspace` 是「作业」整包（里面套了 `系统源代码/`），不用手动拆 —— 部署脚本会自动下钻。

---

## 3. 安装运行环境（会装包、改防火墙、改 SELinux 布尔值，属于高影响操作）

```bash
bash scripts/10_runtime.sh
```

脚本会逐项**向你确认**，每项确认后才执行。它做的事：

1. 检查 Python，低于 3.10 时 `dnf install python3.11`；
2. 安装 `tar gzip curl rsync unzip policycoreutils-python-utils`；
3. `firewall-cmd` 放行 http/https；
4. **SELinux**：`setsebool -P httpd_can_network_connect 1`（不开这个，Nginx 反代会 502）；
5. 创建 `/www/wwwroot/oc-emporiumretai-ms.com/{app,data,backup}` 并 `chown www:www`。

**期望**：

```
>> 4) SELinux：允许 Nginx 反代到本机端口
  当前 httpd_can_network_connect = off
  即将执行: setsebool -P httpd_can_network_connect 1
  是否继续? [y/N] y
  [OK]   已开启（Nginx 才能 proxy_pass 到 127.0.0.1:19870）
```

---

## 4. 部署应用（systemd 托管，只监听 127.0.0.1）

```bash
bash scripts/20_deploy_app.sh /app/workspace oc-emporiumretai-ms.com
```

它做的事：定位源码 → 校验 `run.py/server/web` → rsync 到 `/www/wwwroot/<域名>/app`（**不覆盖 data**）→ 复制随包数据库到 `data/` → 写 `/etc/systemd/system/store-assistant.service` → 启动 → 本机健康检查。

**期望**：

```
[OK]   源码校验通过（run.py / server / web 齐全）
[OK]   使用 /usr/bin/python3.11（3.11）
[OK]   数据库就位: /www/wwwroot/oc-emporiumretai-ms.com/data/store.db (2.2M)
[OK]   已写入 /etc/systemd/system/store-assistant.service
[OK]   服务运行中
  HTTP 200  {"ok": true, "status": "up", "database": "ok", ...}
```

**关键设计**：应用监听 `127.0.0.1:19870`，公网只暴露 Nginx 的 443。原因：Python 的 `http.server` 没有抗攻击能力，直接暴露公网风险高。

手工常用命令：

```bash
systemctl status store-assistant          # 状态
journalctl -u store-assistant -n 100 -f   # 实时日志
systemctl restart store-assistant         # 重启
```

---

## 5. 建站与 Nginx 反向代理

```bash
bash scripts/30_nginx.sh oc-emporiumretai-ms.com
```

脚本做的事：
1. 校验 nginx 与 vhost 目录；
2. 证书目录先放一份**自签名证书**（否则 `nginx -t` 会因缺证书失败，这是新手最常踩的坑）；
3. 备份旧 vhost → 写入新 vhost → `nginx -t` → reload；
4. 用 `curl -H "Host: …"` 本机自测。

vhost 模板位置：`conf/nginx_oc-emporiumretai-ms.conf`，落到
`/www/server/panel/vhost/nginx/oc-emporiumretai-ms.com.conf`。

要点：
- 80 端口只做 `/.well-known` 校验 + 301 跳 HTTPS；
- 443 反代到 `127.0.0.1:19870`，并传 `X-Forwarded-Proto`（应用靠它判断走 HTTPS，给 Cookie 加 Secure）；
- 显式 `proxy_set_header Host $host`，否则应用生成的绝对链接会指向 127.0.0.1；
- 不使用 `http2 on;`（需要 nginx ≥ 1.25.1，宝塔常见 1.20~1.24 会报 unknown directive）。

> 宝塔「网站」列表里如果没有这个站点，是因为我们直接写了 vhost 文件。想让它出现在面板里：
> 面板 → 网站 → 添加站点 → 域名填同一个 → 根目录填 `/www/wwwroot/oc-emporiumretai-ms.com/app` → 提交，
> **但提交后不要再用面板的「反向代理」功能**，以本 vhost 为准。

---

## 6. 开启 HTTPS

三条路径，最终都落到同一对文件，Nginx 配置不用改：

```
/www/server/panel/vhost/cert/oc-emporiumretai-ms.com/fullchain.pem
/www/server/panel/vhost/cert/oc-emporiumretai-ms.com/privkey.pem
```

### 路径 A：宝塔面板（推荐）

```bash
bash scripts/40_ssl.sh --bt      # 打印面板操作步骤，照做即可
```

面板操作：网站 → 设置 → SSL → Let's Encrypt → 勾选两个域名 → 文件验证 → 申请。
成功后宝塔自动写入证书目录，并自带续期任务。

### 路径 B：certbot（面板 SSL 报错时兜底）

```bash
bash scripts/40_ssl.sh --certbot
```

它用 webroot 方式签发，`--deploy-hook` 把证书复制到宝塔证书目录并 reload nginx；最后跑 `certbot renew --dry-run` 验证续期链路。

### 路径 C：阿里云免费证书（额度用完时兜底）

控制台申请 → 下载 **Nginx 格式** → 上传解压 → 

```bash
bash scripts/40_ssl.sh --manual /root/alicert
```

> 手工证书不会自动续期，到期前 30 天要重新导入。

**验证**：

```bash
openssl s_client -connect oc-emporiumretai-ms.com:443 -servername oc-emporiumretai-ms.com </dev/null 2>/dev/null | openssl x509 -noout -subject -dates
```

期望 `subject=CN = oc-emporiumretai-ms.com`，且 `notAfter` 在 90 天内（Let's Encrypt）。

---

## 7. 创建 MySQL 数据库并记录凭据

> **已确认的部署决策：业务数据用 SQLite 上线，MySQL 作为配套报表库。**
> 理由：应用按"单店、单机、解压即用"设计，数据层没有 MySQL 驱动；单店写入量（< 10 TPS）SQLite 完全够，
> 且备份就是复制一个文件。MySQL 则承担"可 SQL 查询的报表副本"角色（按日销售、商品库存、赊账余额），
> 供 BI、外部报表工具或课程演示直接连。
> 若日后要求业务数据进 MySQL，改造路径与工作量见《运维复现指南》第 6 节。

```bash
MYSQL_ROOT_PASSWORD='宝塔面板里看到的root密码' bash scripts/50_mysql.sh
# 或交互式： bash scripts/50_mysql.sh
```

脚本做的事：连接测试（先试免密，再试密码）→ 建库建号（幂等，可重复执行）→ 用新账号验证登录 → 凭据落盘 `600`。

**脚本结束会打印并写入 `/root/.oc_store_mysql.cnf`**，形如：

| 项目 | 值（示例，实际以脚本输出为准） |
|---|---|
| 数据库名 | `oc_store` |
| 用户名 | `oc_store_user` |
| 密码 | 24 位随机串（脚本生成，勿用示例值） |
| 主机端口 | `127.0.0.1:3306` |
| 字符集 | `utf8mb4` |
| 人读凭据 | `/root/.oc_store_mysql.cnf`（600） |
| 工具凭据 | `/root/.oc_store_mysql_tool.cnf`（600，mysqldump 用） |
| 连接串 | `mysql://oc_store_user:<密码>@127.0.0.1:3306/oc_store` |

**在宝塔面板里也能看到**：数据库 → 列表里会出现 `oc_store`。

### 7.1 把报表数据同步进 MySQL（让配套库有内容）

```bash
bash scripts/55_mysql_sync.sh            # 生成 + 写入 + 回读校验
bash scripts/55_mysql_sync.sh --dry-run  # 只看生成的 SQL
```

它从 SQLite 读汇总，写成 MySQL 的四张表（幂等 `REPLACE INTO`，可反复跑）：

| MySQL 表 | 内容 | 来源 |
|---|---|---|
| `daily_sales` | 按日 单数/销售额/成本/毛利/毛利率 | `SaleOrder` |
| `product_stock` | 每个商品的现存数量、库存成本、售价 | `vProductStock` |
| `credit_outstanding` | 每个顾客的赊账余额与账龄 | `vCreditSummary` + `CreditAccount` |
| `sync_log` | 每次同步的时间与行数留痕 | 脚本写入 |

本地已在真实库上验证生成器：**46 天日汇总 / 107 个商品 / 6 个赊账账户**，行数与库内一致、引号转义无残留。

查一下效果：

```bash
mysql --defaults-extra-file=/root/.oc_store_mysql_tool.cnf \
  -e "USE oc_store; SELECT * FROM daily_sales ORDER BY sale_date DESC LIMIT 7;"
```

---

## 8. 上线前必做：换掉演示口令（安全红线）

源码里的演示账号是 `boss/boss123`、`stocker/stocker123`、`sales/sales123`、`supplier/supplier123`。
**站点一旦公网可达，这四个口令等于把后台交出去。**

```bash
cd /www/wwwroot/oc-emporiumretai-ms.com/app
sudo -u www env STORE_DATA_DIR=/www/wwwroot/oc-emporiumretai-ms.com/data \
  /usr/bin/python3.11 /root/oc-deploy/scripts/rotate_password.py --all
systemctl restart store-assistant
```

**期望**：打印一张表（登录名 / 姓名 / 角色 / 新口令），并写入 `/root/.oc_store_admin_rotated`（600）。
把口令存进密码管理器，并删除本机聊天记录里的明文。

> 只想改老板账号：`--user boss`；想指定统一口令：`--password '你的强口令'`。

另外建议：把页脚加上备案号（见第 0 节），并在 `web/js/app.js` 里去掉登录页的"演示身份"卡片（可选，不影响功能）。

---

## 9. 验收：15 项全过才算完成

```bash
bash scripts/60_verify.sh oc-emporiumretai-ms.com
```

覆盖：systemd 状态与监听、应用健康、数据库连接、首页与登录页、`nginx -t`、vhost 存在、HTTP 301、443 握手、证书域名匹配与有效期、公网 HTTPS、数据库文件、备份脚本、口令已换。

**期望结尾**：

```
------------------------------------------------------------
结果：通过 15 项，失败 0 项
------------------------------------------------------------
全部通过。访问地址：https://oc-emporiumretai-ms.com
```

失败时会打印四步排查指引（status → journalctl → nginx error.log → 体检脚本）。

---

## 10. 定时任务（备份 + 巡检）

```bash
# 编辑 root 的 crontab
crontab -e
```

加入：

```cron
# 每天 02:30 备份（数据库 + 配置快照 + MySQL 预留库），保留 30 天
30 2 * * * /bin/bash /root/oc-deploy/scripts/70_backup.sh --keep 30 >> /var/log/oc-backup.log 2>&1
# 每天 03:10 把报表数据同步进 MySQL（配套库）
10 3 * * * /bin/bash /root/oc-deploy/scripts/55_mysql_sync.sh >> /var/log/oc-mysql-sync.log 2>&1
# 每 5 分钟健康巡检，不通自动重启
*/5 * * * * /bin/bash /root/oc-deploy/scripts/90_healthcheck.sh >> /var/log/oc-health.log 2>&1
```

> 宝塔面板自带「计划任务」，也可以在面板里加同样两条，便于可视化查看日志。

验证：`bash scripts/70_backup.sh` 后看 `/www/wwwroot/<域名>/backup/db/` 是否出现 `store-*.db`。

---

## 11. 交付信息表（部署完成后填写）

| 项目 | 值 |
|---|---|
| 访问地址 | `https://oc-emporiumretai-ms.com`（`http://` 自动 301） |
| 备用地址 | `https://www.oc-emporiumretai-ms.com` |
| 服务器 | 阿里云 ECS，实例 ID `213913b62b264af6bc51fb177ed3744b` |
| 站点目录 | `/www/wwwroot/oc-emporiumretai-ms.com/app` |
| 数据目录 | `/www/wwwroot/oc-emporiumretai-ms.com/data` |
| 备份目录 | `/www/wwwroot/oc-emporiumretai-ms.com/backup` |
| systemd 服务 | `store-assistant`（开机自启） |
| 监听 | `127.0.0.1:19870`（仅本机） |
| Nginx vhost | `/www/server/panel/vhost/nginx/oc-emporiumretai-ms.com.conf` |
| 证书目录 | `/www/server/panel/vhost/cert/oc-emporiumretai-ms.com/` |
| 访问日志 | `/www/wwwlogs/oc-emporiumretai-ms.com.log` |
| 错误日志 | `/www/wwwlogs/oc-emporiumretai-ms.com.error.log` |
| MySQL 库 | `oc_store` / `oc_store_user`（密码见 `/root/.oc_store_mysql.cnf`） |
| 应用账号 | 见 `/root/.oc_store_admin_rotated` |

---

## 12. 故障排查对照表

| 现象 | 最可能原因 | 一条命令定位 | 处理 |
|---|---|---|---|
| 502 Bad Gateway | 应用没起 / SELinux 拦截 | `systemctl status store-assistant`；`tail -20 /www/wwwlogs/*.error.log` | `systemctl restart store-assistant`；`setsebool -P httpd_can_network_connect 1` |
| 502 但应用正常 | 端口不一致 | `ss -lntp \| grep 19870` | 检查 unit 的 PORT 与 vhost 的 proxy_pass 是否一致 |
| 403 Forbidden | 目录权限 / SELinux 上下文不对 | `ls -ld /www/wwwroot/<域名>/app` | `chown -R www:www` + `restorecon -R` |
| 500 且日志有 Permission denied | data 目录不可写 | `ls -ld data` | `chown www:www data && chmod 750 data` |
| 打开是白屏、样式全丢 | 静态资源 MIME/路径错 | 浏览器 F12 → Console/Network | 确认 `/css/app.css` 返回 200 且 `Content-Type: text/css` |
| 证书申请失败 | 80 未通 / 解析未生效 / 备案未完成 | `curl -I http://oc-emporiumretai-ms.com/.well-known/acme-challenge/ping` | 逐项修前置条件后重试 |
| 浏览器仍显示旧证书 | 缓存或未 reload | `systemctl reload nginx` | 换浏览器隐私窗口验证 |
| 登录后马上掉线 | Cookie 的 Secure 与协议不一致 | `curl -I https://…/` 看 `Set-Cookie` | 确认走的是 HTTPS，且 unit 里 `COOKIE_SECURE=1` |
| 网站打不开但服务器能 curl 通 | 安全组/备案/DNS | 手机 4G 访问 + 阿里云控制台安全组 | 放行 443、等 DNS 生效、确认备案 |
| 磁盘满 | 日志/备份堆积 | `df -h`；`du -sh /www/wwwlogs /www/wwwroot/*/backup` | 清日志、调小备份保留天数 |

---

## 13. 一键顺序（复制即用）

```bash
# 0) 上传部署包到 /root/oc-deploy（含 conf/ 与 scripts/）
cd /root/oc-deploy

# 1) 体检
bash scripts/00_preflight.sh oc-emporiumretai-ms.com

# 2) 环境（逐项确认）
bash scripts/10_runtime.sh

# 3) 应用
bash scripts/20_deploy_app.sh /app/workspace oc-emporiumretai-ms.com

# 4) Nginx
bash scripts/30_nginx.sh oc-emporiumretai-ms.com

# 5) 证书（面板操作，或 certbot / 手动）
bash scripts/40_ssl.sh --bt

# 6) MySQL（记录账密）+ 同步报表数据
MYSQL_ROOT_PASSWORD='***' bash scripts/50_mysql.sh
bash scripts/55_mysql_sync.sh

# 7) 换口令（安全红线）
cd /www/wwwroot/oc-emporiumretai-ms.com/app
sudo -u www env STORE_DATA_DIR=/www/wwwroot/oc-emporiumretai-ms.com/data \
  /usr/bin/python3.11 /root/oc-deploy/scripts/rotate_password.py --all
systemctl restart store-assistant
cd /root/oc-deploy

# 8) 验收
bash scripts/60_verify.sh oc-emporiumretai-ms.com

# 9) 定时任务（见第 10 节）
crontab -e
```

---

## 14. 回滚与卸载

```bash
# 回滚到上一个发布版本
ls /www/wwwroot/oc-emporiumretai-ms.com/backup/releases
bash scripts/80_release.sh rollback 20261118-131500

# 恢复某个数据库备份（高危，需输入 RESTORE 确认）
bash scripts/71_restore.sh /www/wwwroot/oc-emporiumretai-ms.com/backup/db/store-20261118-023000.db

# 完整卸载（保留备份，先确认再执行）
systemctl disable --now store-assistant
rm -f /etc/systemd/system/store-assistant.service && systemctl daemon-reload
rm -f /www/server/panel/vhost/nginx/oc-emporiumretai-ms.com.conf && systemctl reload nginx
# 数据与备份不要直接删，先另存：
tar -czf /root/oc-store-final-$(date +%F).tar.gz -C /www/wwwroot oc-emporiumretai-ms.com
```

---

**验证边界声明**：本手册里的命令与配置是按 Alibaba Cloud Linux 4 + 宝塔常见布局写的，脚本已做幂等与前置校验；但**没有在你这台 ECS 上实际执行过**（当前环境拿不到该实例的登录入口）。实际投放时按第 13 节顺序执行，每一步的输出发我，我按输出纠偏。
