#!/usr/bin/env bash
# 10 运行环境（会安装软件包、放行防火墙端口、调整 SELinux 布尔值 —— 属于高影响操作）
# 用法: bash 10_runtime.sh            # 交互确认
#       bash 10_runtime.sh --yes      # 免确认（仅在你已明确同意时使用）
set -eu

AUTO="no"
if [ "${1:-}" = "--yes" ]; then AUTO="yes"; fi

line() { printf '%s\n' "------------------------------------------------------------"; }
step() { printf '\n>> %s\n' "$1"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
warn() { printf '  [WARN] %s\n' "$1"; }

confirm() {
  if [ "$AUTO" = "yes" ]; then printf '  (--yes) 跳过确认: %s\n' "$1"; return 0; fi
  printf '  即将执行: %s\n  是否继续? [y/N] ' "$1"
  read -r ans
  case "$ans" in y|Y|yes|YES) return 0 ;; *) printf '  已跳过。\n'; return 1 ;; esac
}

line
printf '运行环境准备（Alibaba Cloud Linux 4 + 宝塔面板）\n'
line

step "1) 检查 Python 版本"
PYV="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])' 2>/dev/null || echo none)"
printf '  当前 python3: %s\n' "$PYV"
NEED_INSTALL="no"
case "$PYV" in
  3.1[0-9]|3.[2-9][0-9]) ok "满足 >= 3.10，无需安装" ;;
  *) NEED_INSTALL="yes" ;;
esac

if [ "$NEED_INSTALL" = "yes" ]; then
  warn "需要安装 python3.11（dnf）"
  if confirm "dnf install -y python3.11 python3.11-pip"; then
    dnf install -y python3.11 python3.11-pip
    if [ -x /usr/bin/python3.11 ]; then
      ok "python3.11 安装完成"
      printf '  提示: 后面的 unit 里 ExecStart 请使用 /usr/bin/python3.11\n'
    else
      printf '  [FAIL] 安装后仍未找到 /usr/bin/python3.11，请检查 dnf 源\n'
      exit 1
    fi
  fi
fi

step "2) 基础工具"
for pkg in tar gzip curl rsync unzip policycoreutils-python-utils; do
  if rpm -q "$pkg" >/dev/null 2>&1; then ok "$pkg 已安装"; else
    if confirm "dnf install -y $pkg"; then dnf install -y "$pkg" || warn "$pkg 安装失败（非致命）"; fi
  fi
done

step "3) 防火墙放行 80/443（阿里云安全组仍需在控制台放行）"
if command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  if confirm "firewall-cmd --permanent --add-service=http/https && reload"; then
    firewall-cmd --permanent --add-service=http
    firewall-cmd --permanent --add-service=https
    firewall-cmd --reload
    ok "firewalld 已放行 http/https"
  fi
else
  warn "firewalld 未运行，跳过（若用 iptables/nftables 请自行放行）"
fi

step "4) SELinux：允许 Nginx 反代到本机端口"
if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
  CUR="$(getsebool httpd_can_network_connect 2>/dev/null | awk '{print $3}')"
  printf '  当前 httpd_can_network_connect = %s\n' "${CUR:-unknown}"
  if [ "${CUR:-off}" != "on" ]; then
    if confirm "setsebool -P httpd_can_network_connect 1"; then
      setsebool -P httpd_can_network_connect 1
      ok "已开启（Nginx 才能 proxy_pass 到 127.0.0.1:19870）"
    fi
  else
    ok "已经是 on"
  fi
  printf '  如果后续出现 502 且 nginx error.log 有 "Permission denied"，执行:\n'
  printf '    setsebool -P httpd_can_network_connect 1\n'
else
  printf '  SELinux 已关闭或不可用，跳过\n'
fi

step "5) 站点与数据目录骨架"
DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
if confirm "创建 ${SITE}/{app,data,backup} 并设置属主 www:www"; then
  mkdir -p "${SITE}/app" "${SITE}/data" "${SITE}/backup"
  if id www >/dev/null 2>&1; then
    chown -R www:www "${SITE}"
    ok "属主设置为 www:www"
  else
    warn "系统里没有 www 用户（非宝塔环境？），跳过 chown"
  fi
  chmod 750 "${SITE}/data"
  ok "目录就绪"
fi

line
printf '完成。下一步: bash 20_deploy_app.sh\n'
