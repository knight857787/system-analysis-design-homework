#!/usr/bin/env python3
"""把演示口令换成强口令（上线前必做）。

用法（在服务器上、应用目录执行）：
    sudo -u www env STORE_DATA_DIR=/www/wwwroot/<域名>/data \
        python3 /root/oc-deploy/scripts/rotate_password.py --all
    sudo -u www env STORE_DATA_DIR=... python3 rotate_password.py --user boss

说明：
  - 复用应用自己的 scrypt 实现（server.core.hash_password），不另写一套散列；
  - 直接改 SQLite 里的 PasswordHash，不经过 HTTP，因此不依赖登录；
  - 成功后写 /root/.oc_store_admin_rotated 作为"已换密码"的标记，供验收脚本识别。
"""
from __future__ import annotations

import argparse
import os
import secrets
import sqlite3
import string
import sys
from datetime import datetime

APP_DIR = os.environ.get('APP_DIR') or os.getcwd()
sys.path.insert(0, APP_DIR)

try:
    from server.core import hash_password
except Exception as exc:  # noqa: BLE001
    print(f'[FAIL] 无法导入 server.core：{exc}')
    print('       请在应用目录下执行，或设置 APP_DIR 指向应用目录')
    sys.exit(1)


def gen_password(length: int = 16) -> str:
    alphabet = string.ascii_letters + string.digits
    return ''.join(secrets.choice(alphabet) for _ in range(length))


def main() -> int:
    parser = argparse.ArgumentParser(description='重置演示账号口令')
    parser.add_argument('--user', action='append', default=[], help='要重置的登录名，可重复')
    parser.add_argument('--all', action='store_true', help='重置全部账号')
    parser.add_argument('--password', default='', help='指定统一新口令（留空则每人随机生成）')
    parser.add_argument('--data', default='', help='数据目录（默认读 STORE_DATA_DIR 或 ./data）')
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()

    data_dir = args.data or os.environ.get('STORE_DATA_DIR') or os.path.join(APP_DIR, 'data')
    db_path = os.path.join(data_dir, 'store.db')
    if not os.path.isfile(db_path):
        print(f'[FAIL] 找不到数据库：{db_path}')
        return 1

    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    rows = conn.execute('SELECT EmployeeID, LoginName, Name, Role FROM Employee WHERE RecordStatus="A"').fetchall()
    if not rows:
        print('[FAIL] Employee 表为空')
        return 1

    targets = rows if args.all else [r for r in rows if r['LoginName'] in set(args.user)]
    if not targets:
        print('用法：--all 重置全部，或 --user <登录名> 指定；现有账号：')
        for r in rows:
            print(f"  {r['LoginName']:<10} {r['Name']:<12} {r['Role']}")
        return 1

    print(f'数据库：{db_path}')
    print(f'{"登录名":<10}{"姓名":<14}{"角色":<14}{"新口令":<20}')
    print('-' * 62)
    issued = []
    for r in targets:
        pwd = args.password or gen_password()
        issued.append((r['LoginName'], r['Name'], r['Role'], pwd))
        print(f"{r['LoginName']:<10}{r['Name']:<14}{r['Role']:<14}{pwd:<20}")
        if args.dry_run:
            continue
        conn.execute(
            'UPDATE Employee SET PasswordHash=?, UpdatedAt=? WHERE EmployeeID=?',
            (hash_password(pwd), datetime.now().strftime('%Y-%m-%d %H:%M:%S'), r['EmployeeID']),
        )
    if not args.dry_run:
        conn.commit()
    conn.close()

    if args.dry_run:
        print('\n[dry-run] 未写入数据库')
        return 0

    marker = '/root/.oc_store_admin_rotated'
    try:
        with open(marker, 'w', encoding='utf-8') as fp:
            fp.write(f'rotated_at={datetime.now().isoformat(timespec="seconds")}\n')
            for login, name, role, pwd in issued:
                fp.write(f'{login}\t{name}\t{role}\t{pwd}\n')
        os.chmod(marker, 0o600)
        print(f'\n凭据已写入 {marker}（600，仅 root 可读）')
    except OSError as exc:
        print(f'\n[WARN] 无法写 {marker}（{exc}），请手动保存上面的口令')

    print('\n请立刻：① 把口令存进密码管理器；② 重启服务（systemctl restart store-assistant）。')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
