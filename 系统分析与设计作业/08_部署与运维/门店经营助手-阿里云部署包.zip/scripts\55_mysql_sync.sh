#!/usr/bin/env bash
# 55 MySQL 配套库同步：把 SQLite 的"报表口径"数据同步进 MySQL（只读 SQLite，不改业务数据）
#
# 定位：业务读写仍由 SQLite 承担（决策见 README 第 7 节）；MySQL 作为配套报表库，
#      存放按日/按商品/按顾客的汇总表，供 BI、SQL 练习、外部报表工具连接使用。
# 特点：幂等（REPLACE INTO），可每日 cron；不需要 Python 的 MySQL 驱动（生成 SQL 交给 mysql 客户端执行）。
# 用法: bash 55_mysql_sync.sh            # 同步一次
#       bash 55_mysql_sync.sh --dry-run  # 只生成 SQL 不执行，打印前 20 行
set -eu

DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
DATA="${STORE_DATA_DIR:-/www/wwwroot/${DOMAIN}/data}"
DB_FILE="${DATA}/store.db"
TOOL_CNF="/root/.oc_store_mysql_tool.cnf"
CRED_FILE="/root/.oc_store_mysql.cnf"
MYSQL_BIN=""
for c in /www/server/mysql/bin/mysql /usr/bin/mysql /usr/local/mysql/bin/mysql; do
  if [ -x "$c" ]; then MYSQL_BIN="$c"; break; fi
done

line() { printf '%s\n' "------------------------------------------------------------"; }
step() { printf '\n>> %s\n' "$1"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

DRY="no"
if [ "${1:-}" = "--dry-run" ]; then DRY="yes"; fi

line
printf 'MySQL 配套报表库同步（源：SQLite，目标：MySQL）\n'
line

[ -f "$DB_FILE" ] || die "找不到 SQLite 数据库: $DB_FILE"
[ -n "$MYSQL_BIN" ] || { [ "$DRY" = "yes" ] || die "找不到 mysql 客户端"; }
[ -f "$TOOL_CNF" ] || { [ "$DRY" = "yes" ] || die "缺少 $TOOL_CNF（先跑 50_mysql.sh）"; }
DB_NAME="$(awk -F= '/^database=/{print $2}' "$CRED_FILE" 2>/dev/null || echo oc_store)"
ok "源库 $DB_FILE（$(du -h "$DB_FILE" | awk '{print $1}')）"
printf '  目标库 %s\n' "$DB_NAME"

OUT="$(mktemp /tmp/oc_mysql_sync_XXXXXX.sql)"

step "1) 从 SQLite 生成汇总 SQL"
python3 - "$DB_FILE" "$DB_NAME" "$OUT" <<'PY'
import sqlite3
import sys
from datetime import datetime

src, db, out = sys.argv[1], sys.argv[2], sys.argv[3]
conn = sqlite3.connect(src)
conn.row_factory = sqlite3.Row


def esc(v):
    if v is None:
        return 'NULL'
    if isinstance(v, (int, float)):
        return str(v)
    s = str(v).replace('\\', '\\\\').replace("'", "\\'")
    return "'" + s + "'"


lines = []
lines.append('SET NAMES utf8mb4;')
lines.append('CREATE DATABASE IF NOT EXISTS `%s` CHARACTER SET utf8mb4;' % db)
lines.append('USE `%s`;' % db)

lines.append('''
CREATE TABLE IF NOT EXISTS daily_sales (
  sale_date DATE PRIMARY KEY,
  orders INT NOT NULL,
  amount DECIMAL(12,2) NOT NULL,
  cost DECIMAL(12,2) NOT NULL,
  profit DECIMAL(12,2) NOT NULL,
  margin DECIMAL(6,2) NOT NULL,
  synced_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='按日销售汇总（来自 SQLite SaleOrder）';

CREATE TABLE IF NOT EXISTS product_stock (
  product_id INT PRIMARY KEY,
  product_name VARCHAR(128) NOT NULL,
  category VARCHAR(64) NOT NULL,
  unit VARCHAR(16) NOT NULL,
  qty DECIMAL(14,3) NOT NULL,
  cost_value DECIMAL(12,2) NOT NULL,
  list_price DECIMAL(12,3) NOT NULL,
  synced_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品现存量与库存成本（来自 vProductStock）';

CREATE TABLE IF NOT EXISTS credit_outstanding (
  customer_id INT PRIMARY KEY,
  customer_name VARCHAR(64) NOT NULL,
  phone VARCHAR(32) NULL,
  credit_limit DECIMAL(12,2) NOT NULL,
  outstanding DECIMAL(12,2) NOT NULL,
  overdue_days INT NOT NULL,
  synced_at DATETIME NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='赊账余额与账龄（来自 vCreditSummary）';

CREATE TABLE IF NOT EXISTS sync_log (
  id INT PRIMARY KEY AUTO_INCREMENT,
  synced_at DATETIME NOT NULL,
  daily_sales_rows INT NOT NULL,
  product_stock_rows INT NOT NULL,
  credit_rows INT NOT NULL,
  source VARCHAR(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='每次同步的行数留痕';
''')

now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

rows = conn.execute('''
    SELECT date(OccurredAt) AS d, COUNT(*) AS n,
           ROUND(SUM(TotalAmount),2) AS amt, ROUND(SUM(CostAmount),2) AS cost,
           ROUND(SUM(ProfitAmount),2) AS profit
    FROM SaleOrder WHERE RecordStatus='A'
    GROUP BY date(OccurredAt) ORDER BY d
''').fetchall()
for r in rows:
    margin = round((r['profit'] or 0) / r['amt'] * 100, 2) if r['amt'] else 0
    lines.append('REPLACE INTO daily_sales VALUES (%s,%d,%s,%s,%s,%s,%s);' % (
        esc(r['d']), r['n'], esc(r['amt']), esc(r['cost']), esc(r['profit']), esc(margin), esc(now)))
n_daily = len(rows)

rows = conn.execute('''
    SELECT v.ProductID, v.ProductName, v.CategoryName, v.Unit,
           ROUND(v.StockQty,3), ROUND(v.StockValue,2), v.ListPrice
    FROM vProductStock v ORDER BY v.ProductID
''').fetchall()
for r in rows:
    lines.append('REPLACE INTO product_stock VALUES (%d,%s,%s,%s,%s,%s,%s,%s);' % (
        r[0], esc(r[1]), esc(r[2]), esc(r[3]), esc(r[4]), esc(r[5]), esc(r[6]), esc(now)))
n_stock = len(rows)

rows = conn.execute('''
    SELECT s.CustomerID, s.CustomerName, s.Phone, s.CreditLimit,
           ROUND(s.OutstandingAmount,2) AS outstanding,
           COALESCE(a.OverdueDays, 0) AS overdue
    FROM vCreditSummary s
    LEFT JOIN CreditAccount a ON a.AccountID = s.AccountID
    ORDER BY s.CustomerID
''').fetchall()
for r in rows:
    lines.append('REPLACE INTO credit_outstanding VALUES (%d,%s,%s,%s,%s,%d,%s);' % (
        r[0], esc(r[1]), esc(r[2]), esc(r[3]), esc(r[4]), int(r[5] or 0), esc(now)))
n_credit = len(rows)

lines.append("INSERT INTO sync_log (synced_at, daily_sales_rows, product_stock_rows, credit_rows, source) "
             "VALUES (%s,%d,%d,%d,%s);" % (esc(now), n_daily, n_stock, n_credit, esc(src)))

with open(out, 'w', encoding='utf-8') as fp:
    fp.write('\n'.join(lines) + '\n')
print('  生成完成：daily_sales=%d 行，product_stock=%d 行，credit=%d 行' % (n_daily, n_stock, n_credit))
print('  SQL 文件：%s（%d 行）' % (out, len(lines)))
PY
ok "SQL 已生成: $OUT"

if [ "$DRY" = "yes" ]; then
  step "2) dry-run：预览前 20 行"
  sed -n '1,20p' "$OUT" | sed 's/^/  /'
  printf '  ...（完整文件：%s）\n' "$OUT"
  exit 0
fi

step "2) 执行同步"
if "$MYSQL_BIN" --defaults-extra-file="$TOOL_CNF" < "$OUT"; then
  ok "写入成功"
else
  die "写入失败，检查 $TOOL_CNF 的账号与权限"
fi

step "3) 回读校验"
"$MYSQL_BIN" --defaults-extra-file="$TOOL_CNF" -N -B -e "
USE \`$DB_NAME\`;
SELECT 'daily_sales', COUNT(*) FROM daily_sales
UNION ALL SELECT 'product_stock', COUNT(*) FROM product_stock
UNION ALL SELECT 'credit_outstanding', COUNT(*) FROM credit_outstanding
UNION ALL SELECT 'sync_log', COUNT(*) FROM sync_log;" | sed 's/^/  /'

rm -f "$OUT"
line
printf '完成。MySQL 现在是可查询的报表库：\n'
printf '  mysql --defaults-extra-file=%s -e "USE %s; SELECT * FROM daily_sales ORDER BY sale_date DESC LIMIT 7;"\n' "$TOOL_CNF" "$DB_NAME"
