#!/usr/bin/env bash
# 20 部署应用：同步源码 → 安装 systemd 服务 → 启动 → 健康检查
# 用法: bash 20_deploy_app.sh [源码目录] [域名]
#   源码目录默认 /app/workspace；若该目录是“作业”整包（含 系统源代码/），脚本会自动下钻
set -eu

SRC_ARG="${1:-/app/workspace}"
DOMAIN="${2:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
APP="${SITE}/app"
DATA="${SITE}/data"
SERVICE="/etc/systemd/system/store-assistant.service"
PORT="${PORT:-19870}"
UNIT_SRC="$(dirname "$0")/../conf/store-assistant.service"

line() { printf '%s\n' "------------------------------------------------------------"; }
step() { printf '\n>> %s\n' "$1"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
warn() { printf '  [WARN] %s\n' "$1"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

line
printf '部署门店经营助手到 %s\n' "$SITE"
line

step "1) 定位源码根目录"
SRC="$SRC_ARG"
if [ ! -d "$SRC" ]; then die "源码目录不存在: $SRC"; fi
if [ -f "$SRC/系统源代码/run.py" ]; then
  SRC="$SRC/系统源代码"; ok "自动下钻到打包目录: $SRC"
elif [ -d "$SRC/作业/系统源代码" ]; then
  SRC="$SRC/作业/系统源代码"; ok "自动下钻到 作业/系统源代码"
fi
[ -f "$SRC/run.py" ] || die "$SRC 下没有 run.py，源码层级不对"
[ -d "$SRC/server" ] || die "$SRC 下没有 server/，源码不完整"
[ -d "$SRC/web" ]    || die "$SRC 下没有 web/，源码不完整"
ok "源码校验通过（run.py / server / web 齐全）"

step "2) 选择 Python 解释器"
PYBIN="$(command -v python3 || true)"
if [ -x /usr/bin/python3.11 ]; then PYBIN=/usr/bin/python3.11; fi
[ -n "$PYBIN" ] || die "找不到 python3"
PYV="$("$PYBIN" -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
case "$PYV" in
  3.1[0-9]|3.[2-9][0-9]) ok "使用 $PYBIN（$PYV）" ;;
  *) die "Python $PYV 低于 3.10，请先执行 10_runtime.sh" ;;
esac

step "3) 准备站点目录"
mkdir -p "$APP" "$DATA" "${SITE}/backup"
if id www >/dev/null 2>&1; then OWNER="www:www"; else OWNER="$(id -un):$(id -gn)"; warn "无 www 用户，改用 $OWNER"; fi

step "4) 同步源码（保留服务器上的 data/ 与 backup/）"
SRC_OK="yes"
if command -v rsync >/dev/null 2>&1; then
  rsync -a --delete \
    --exclude 'data/' --exclude '__pycache__/' --exclude '*.pyc' --exclude '.git/' \
    "${SRC}/" "${APP}/" || SRC_OK="no"
else
  cp -a "${SRC}/." "${APP}/" || SRC_OK="no"
  rm -rf "${APP}/__pycache__" "${APP}/server/__pycache__" "${APP}/server/routes/__pycache__" 2>/dev/null || true
fi
[ "$SRC_OK" = "yes" ] || die "源码同步失败"
ok "源码已同步到 $APP（$(find "$APP" -type f | wc -l) 个文件）"

step "5) 首启数据库（如果没有随包库）"
if [ -f "$APP/data/store.db" ] && [ ! -f "$DATA/store.db" ]; then
  cp -a "$APP/data/store.db" "$DATA/store.db"
  ok "从源码包复制随包数据库到 $DATA/store.db"
fi
if [ ! -f "$DATA/store.db" ]; then
  warn "无 store.db，首次启动会自动建库并生成模拟数据（约 2 MB）"
else
  ok "数据库就位: $DATA/store.db ($(du -h "$DATA/store.db" | awk '{print $1}'))"
fi

step "6) 权限与 SELinux 上下文"
chown -R "$OWNER" "$APP" "$DATA" "${SITE}/backup"
chmod 750 "$DATA"
if command -v getenforce >/dev/null 2>&1 && [ "$(getenforce)" != "Disabled" ]; then
  command -v restorecon >/dev/null 2>&1 && restorecon -R "$SITE" 2>/dev/null || true
  command -v semanage >/dev/null 2>&1 && semanage fcontext -a -t httpd_sys_rw_content_t "${DATA}(/.*)?" 2>/dev/null || true
  ok "已尝试设置 SELinux 上下文（RW 目录标记为 httpd_sys_rw_content_t）"
fi

step "7) 安装 systemd 服务"
[ -f "$UNIT_SRC" ] || die "缺少 unit 模板: $UNIT_SRC"
if [ -f "$SERVICE" ]; then
  cp -a "$SERVICE" "${SERVICE}.bak.$(date +%Y%m%d%H%M%S)"
  ok "已备份原 unit"
fi
sed -e "s|__APP__|${APP}|g" \
    -e "s|__DATA__|${DATA}|g" \
    -e "s|__USER__|${OWNER%%:*}|g" \
    -e "s|__GROUP__|${OWNER##*:}|g" \
    -e "s|__PYBIN__|${PYBIN}|g" \
    -e "s|__PORT__|${PORT}|g" \
    "$UNIT_SRC" > "$SERVICE"
chmod 644 "$SERVICE"
ok "已写入 $SERVICE"

step "8) 启动服务"
systemctl daemon-reload
systemctl enable store-assistant >/dev/null 2>&1 || warn "enable 失败（不影响本次运行）"
systemctl restart store-assistant
sleep 2
if systemctl is-active --quiet store-assistant; then ok "服务运行中"; else
  printf '  最近 40 行日志：\n'
  journalctl -u store-assistant -n 40 --no-pager || true
  die "服务未启动"
fi

step "9) 本机健康检查"
CODE="$(curl -s -o /tmp/_health.json -w '%{http_code}' "http://127.0.0.1:${PORT}/api/health" || true)"
printf '  HTTP %s  %s\n' "$CODE" "$(cat /tmp/_health.json 2>/dev/null || true)"
if [ "$CODE" = "200" ]; then ok "应用健康"; else die "健康检查失败，看 journalctl -u store-assistant -n 80"; fi

line
printf '应用已就绪：127.0.0.1:%s\n下一步: bash 30_nginx.sh %s\n' "$PORT" "$DOMAIN"
