#!/usr/bin/env bash
# 50 MySQL：建库、建账号、授权、落盘凭据（会写数据库 —— 高影响操作）
# 用法:
#   MYSQL_ROOT_PASSWORD='xxx' bash 50_mysql.sh      # 非交互
#   bash 50_mysql.sh                                 # 交互：先尝试免密，再提示输入 root 密码
set -eu

DB_NAME="${DB_NAME:-oc_store}"
DB_USER="${DB_USER:-oc_store_user}"
DB_PASS="${DB_PASS:-}"
CRED_FILE="/root/.oc_store_mysql.cnf"

line() { printf '%s\n' "------------------------------------------------------------"; }
step() { printf '\n>> %s\n' "$1"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
warn() { printf '  [WARN] %s\n' "$1"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

MYSQL_BIN=""
for c in /www/server/mysql/bin/mysql /usr/bin/mysql /usr/local/mysql/bin/mysql; do
  if [ -x "$c" ]; then MYSQL_BIN="$c"; break; fi
done
[ -n "$MYSQL_BIN" ] || die "找不到 mysql 客户端（宝塔一般在 /www/server/mysql/bin/mysql）"
ok "mysql 客户端: $MYSQL_BIN"

# 生成强密码（避免 $ 与引号，便于写进配置文件）
gen_pass() {
  python3 - <<'PY'
import secrets, string
alphabet = string.ascii_letters + string.digits
print(''.join(secrets.choice(alphabet) for _ in range(24)))
PY
}
[ -n "$DB_PASS" ] || DB_PASS="$(gen_pass)"

run_sql() {  # $1 = sql
  if [ -n "${MYSQL_PWD_OPT:-}" ]; then
    printf '%s\n' "$1" | "$MYSQL_BIN" -uroot $MYSQL_PWD_OPT -N -B
  else
    printf '%s\n' "$1" | "$MYSQL_BIN" -uroot -N -B
  fi
}

line
printf 'MySQL 初始化：库 %s / 账号 %s\n' "$DB_NAME" "$DB_USER"
line

step "1) 连接测试"
MYSQL_PWD_OPT=""
if printf 'SELECT 1;\n' | "$MYSQL_BIN" -uroot -N -B >/dev/null 2>&1; then
  ok "root 免密可用（宝塔新装常见）"
else
  if [ -n "${MYSQL_ROOT_PASSWORD:-}" ]; then
    MYSQL_PWD_OPT="-p${MYSQL_ROOT_PASSWORD}"
  else
    printf '  请输入 MySQL root 密码（宝塔面板 → 数据库 → root 密码 可查看/重置）: '
    stty -echo 2>/dev/null || true
    read -r RP
    stty echo 2>/dev/null || true
    printf '\n'
    MYSQL_PWD_OPT="-p${RP}"
  fi
  if printf 'SELECT 1;\n' | "$MYSQL_BIN" -uroot $MYSQL_PWD_OPT -N -B >/dev/null 2>&1; then
    ok "root 密码验证通过"
  else
    die "root 登录失败。请在宝塔面板「数据库」里确认 root 密码，或用 MYSQL_ROOT_PASSWORD 环境变量传入"
  fi
fi

step "2) 建库建号（幂等）"
SQL="
CREATE DATABASE IF NOT EXISTS \`${DB_NAME}\` CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
CREATE USER IF NOT EXISTS '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
ALTER USER '${DB_USER}'@'localhost' IDENTIFIED BY '${DB_PASS}';
GRANT ALL PRIVILEGES ON \`${DB_NAME}\`.* TO '${DB_USER}'@'localhost';
CREATE TABLE IF NOT EXISTS \`${DB_NAME}\`.deployment_meta (
  id INT PRIMARY KEY AUTO_INCREMENT,
  item VARCHAR(64) NOT NULL UNIQUE,
  value VARCHAR(255) NOT NULL,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
REPLACE INTO \`${DB_NAME}\`.deployment_meta (item, value) VALUES
  ('app', 'store-assistant'),
  ('domain', 'oc-emporiumretai-ms.com'),
  ('db_engine_note', 'application data lives in SQLite (see data/store.db); this schema is reserved'),
  ('created_at', NOW());
FLUSH PRIVILEGES;
"
printf '%s\n' "$SQL" | "$MYSQL_BIN" -uroot $MYSQL_PWD_OPT -N -B || die "建库 SQL 执行失败"
ok "数据库与账号已创建/更新"

step "3) 连通性验证（用新账号登录）"
if printf 'SELECT COUNT(*) FROM deployment_meta;\n' | "$MYSQL_BIN" -u"$DB_USER" -p"$DB_PASS" -h127.0.0.1 -N -B >/dev/null 2>&1; then
  ok "新账号可登录并读到表"
else
  warn "新账号 TCP 登录失败（可能 bind-address 限制），不影响本次部署，但请记录"
fi

step "4) 保存凭据到 ${CRED_FILE}（600）"
cat > "$CRED_FILE" <<EOF
# 门店经营助手 · MySQL 连接信息（部署日期 $(date '+%F %T')）
host=127.0.0.1
port=3306
database=${DB_NAME}
user=${DB_USER}
password=${DB_PASS}
charset=utf8mb4
# 说明：应用当前数据存储在 SQLite（/www/wwwroot/oc-emporiumretai-ms.com/data/store.db），
#      本库为按部署要求创建的配套库/预留库，未参与应用读写。
EOF
chmod 600 "$CRED_FILE"
ok "已写入 ${CRED_FILE}"

# 供 mysqldump / mysql 客户端直接使用的 my.cnf 格式（与上面的人读文件分开）
cat > /root/.oc_store_mysql_tool.cnf <<EOF
[client]
host=127.0.0.1
port=3306
user=${DB_USER}
password=${DB_PASS}
default-character-set=utf8mb4
EOF
chmod 600 /root/.oc_store_mysql_tool.cnf
ok "已写入 /root/.oc_store_mysql_tool.cnf（供 mysqldump 使用）"

line
printf '数据库信息（请立即抄到密码管理器）\n'
line
printf '  数据库名 : %s\n' "$DB_NAME"
printf '  用户名   : %s\n' "$DB_USER"
printf '  密码     : %s\n' "$DB_PASS"
printf '  主机     : 127.0.0.1:3306\n'
printf '  字符集   : utf8mb4\n'
printf '  凭据文件 : %s\n' "$CRED_FILE"
printf '  连接串   : mysql://%s:%s@127.0.0.1:3306/%s\n' "$DB_USER" "$DB_PASS" "$DB_NAME"
line
warn "提醒：应用本体用的是 SQLite（data/store.db）。若要把业务数据迁到 MySQL，需改造数据访问层，见运维指南第 6 节。"
