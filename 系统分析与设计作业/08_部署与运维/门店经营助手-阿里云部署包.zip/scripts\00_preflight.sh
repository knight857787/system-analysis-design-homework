#!/usr/bin/env bash
# 00 系统体检（只读，不改任何东西）
# 用法: bash 00_preflight.sh [域名]
set -eu

DOMAIN="${1:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"

line() { printf '%s\n' "------------------------------------------------------------"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
warn() { printf '  [WARN] %s\n' "$1"; }
bad()  { printf '  [FAIL] %s\n' "$1"; }

line
printf '1) 系统与内核\n'
if [ -f /etc/os-release ]; then
  . /etc/os-release
  printf '  %s %s  内核 %s\n' "${NAME:-?}" "${VERSION_ID:-?}" "$(uname -r)"
else
  bad "/etc/os-release 不存在，可能不是 Linux"
fi

line
printf '2) Python\n'
if command -v python3 >/dev/null 2>&1; then
  PYV="$(python3 -c 'import sys;print("%d.%d"%sys.version_info[:2])')"
  printf '  路径 %s\n  版本 %s\n' "$(command -v python3)" "$PYV"
  case "$PYV" in
    3.1[0-9]|3.[2-9][0-9]) ok "满足 >= 3.10" ;;
    *) bad "低于 3.10，应用无法启动；需先跑 10_runtime.sh 安装 python3.11" ;;
  esac
else
  bad "未安装 python3"
fi

line
printf '3) 宝塔面板\n'
if [ -d /www/server/panel ]; then
  ok "/www/server/panel 存在"
  [ -f /www/server/nginx/sbin/nginx ] && ok "面板自带 nginx: $(/www/server/nginx/sbin/nginx -v 2>&1)" || warn "未见 /www/server/nginx/sbin/nginx"
  [ -d /www/server/panel/vhost/nginx ] && ok "vhost 目录存在" || warn "未见 vhost 目录"
  if [ -d /www/server/mysql ]; then
    ok "面板自带 MySQL: $(/www/server/mysql/bin/mysql --version 2>/dev/null || echo '已安装但取版本失败')"
  else
    warn "未见 /www/server/mysql（未安装 MySQL 或使用其他方式）"
  fi
else
  warn "未检测到宝塔面板目录，脚本仍可用但 vhost 路径需按你的环境调整"
fi

line
printf '4) 端口占用\n'
for port in 80 443 19870; do
  if command -v ss >/dev/null 2>&1; then
    HIT="$(ss -lntp 2>/dev/null | awk -v p=":${port}$" '$4 ~ p {print $4}' | head -n1 || true)"
  else
    HIT=""
  fi
  if [ -n "$HIT" ]; then warn "端口 ${port} 已被监听: ${HIT}"; else ok "端口 ${port} 空闲"; fi
done

line
printf '5) 防火墙与 SELinux\n'
if command -v firewall-cmd >/dev/null 2>&1; then
  printf '  firewalld 状态: %s\n' "$(firewall-cmd --state 2>/dev/null || echo not-running)"
  firewall-cmd --list-ports 2>/dev/null | tr ' ' '\n' | grep -E '^(80|443)/' >/dev/null 2>&1 \
    && ok "80/443 已放行" || warn "firewalld 未放行 80/443（阿里云安全组也需要放行）"
else
  warn "未安装 firewalld（ACL4 默认可能使用 firewalld，请确认）"
fi
printf '  SELinux: %s\n' "$(getenforce 2>/dev/null || echo Unknown)"
printf '  httpd_can_network_connect: %s\n' "$(getsebool httpd_can_network_connect 2>/dev/null || echo '无法读取')"

line
printf '6) 源码目录 /app/workspace\n'
if [ -d /app/workspace ]; then
  ok "/app/workspace 存在"
  if [ -f /app/workspace/run.py ]; then
    ok "检测到 run.py（应用根目录）"
  elif [ -d /app/workspace/server ] && [ -d /app/workspace/web ]; then
    ok "检测到 server/ 与 web/（应用根目录）"
  else
    warn "目录里未见 run.py / server / web，请确认源码层级"
  fi
  printf '  文件数: %s  占用: %s\n' "$(find /app/workspace -type f 2>/dev/null | wc -l)" "$(du -sh /app/workspace 2>/dev/null | awk '{print $1}')"
else
  bad "/app/workspace 不存在（需要先上传源码，或在 Windows 侧用 upload.ps1 上传）"
fi

line
printf '7) 站点目录\n'
if [ -d "$SITE" ]; then ok "$SITE 已存在"; else warn "$SITE 尚未创建（20_deploy_app.sh 会创建）"; fi

line
printf '8) 域名解析（需要在能上网的环境执行）\n'
if command -v getent >/dev/null 2>&1; then
  printf '  %s -> %s\n' "$DOMAIN" "$(getent hosts "$DOMAIN" | awk '{print $1}' | paste -sd, - 2>/dev/null || echo '解析失败')"
else
  warn "无 getent，跳过"
fi

line
printf '9) 磁盘与内存\n'
df -h / /www 2>/dev/null | sed 's/^/  /'
free -m 2>/dev/null | sed 's/^/  /'

line
printf '体检结束。所有 [FAIL] 必须先处理，[WARN] 按手册对应章节处理。\n'
