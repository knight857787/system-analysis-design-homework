#!/bin/bash
# 96 演示数据复位：把业务库恢复成 pristine 快照（交作业演示用，防被改乱）
# 用法: bash 96_demo_reset.sh [--snapshot] [--yes]
#   --snapshot  把当前库另存为 pristine 快照（初始化时用一次）
#   --yes       不交互确认
set -u
DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
DATA="${SITE}/data"
PRISTINE="${DATA}/pristine.db"
MODE="${1:-reset}"

TS="$(date '+%F %T')"
echo "[$TS] mode=$MODE"

if [ "$MODE" = "--snapshot" ]; then
  if [ ! -f "${DATA}/store.db" ]; then echo "找不到 store.db"; exit 1; fi
  python3 - "$DATA/store.db" "$PRISTINE" <<'PY'
import sqlite3, sys
with sqlite3.connect(sys.argv[1]) as s, sqlite3.connect(sys.argv[2]) as d:
    s.backup(d)
print('snapshot ->', sys.argv[2])
PY
  chown ocapp:ocapp "$PRISTINE" 2>/dev/null || true
  chmod 640 "$PRISTINE"
  echo "快照完成"
  exit 0
fi

[ -f "$PRISTINE" ] || { echo "没有 pristine.db，先跑一次 --snapshot"; exit 1; }

if [ "${2:-}" != "--yes" ]; then
  printf '将用 pristine.db 覆盖 store.db（当前数据丢失），确认? [y/N] '
  read -r a
  case "$a" in y|Y) ;; *) echo "已取消"; exit 0 ;; esac
fi

systemctl stop store-assistant
cp -a "$DATA/store.db" "${DATA}/store.db.before-reset.$(date +%Y%m%d%H%M%S)" 2>/dev/null || true
rm -f "${DATA}/store.db-wal" "${DATA}/store.db-shm"
cp -a "$PRISTINE" "${DATA}/store.db"
chown ocapp:ocapp "${DATA}/store.db"
chmod 640 "${DATA}/store.db"
systemctl start store-assistant
sleep 2
code=$(curl -s -o /dev/null -w '%{http_code}' http://127.0.0.1:19870/api/health)
echo "[$(date '+%F %T')] 复位完成 health=$code"
