#!/usr/bin/env bash
# 90 健康巡检（给 cron 用）：不通就重启服务，并把结果写日志
# cron: */5 * * * * /bin/bash /root/oc-deploy/scripts/healthcheck.sh >> /var/log/oc-health.log 2>&1
set -eu

PORT="${PORT:-19870}"
DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
LOG=/var/log/oc-health.log
TS="$(date '+%F %T')"

code_local="$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "http://127.0.0.1:${PORT}/api/health" || echo 000)"
code_public="$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "https://${DOMAIN}/api/health" || echo 000)"

printf '%s local=%s public=%s\n' "$TS" "$code_local" "$code_public" >> "$LOG"

if [ "$code_local" != "200" ]; then
  printf '%s [ACTION] 本地不健康，重启 store-assistant\n' "$TS" >> "$LOG"
  systemctl restart store-assistant || true
  sleep 3
  after="$(curl -s -o /dev/null -w '%{http_code}' --max-time 5 "http://127.0.0.1:${PORT}/api/health" || echo 000)"
  printf '%s [AFTER] %s\n' "$TS" "$after" >> "$LOG"
  [ "$after" = "200" ] || printf '%s [ALERT] 重启后仍不健康，需人工介入\n' "$TS" >> "$LOG"
fi

if [ "$code_public" = "000" ]; then
  printf '%s [ALERT] 公网不可达（查 DNS / 安全组 / 证书 / nginx）\n' "$TS" >> "$LOG"
fi

# 日志按 5MB 轮转
if [ -f "$LOG" ] && [ "$(stat -c%s "$LOG")" -gt 5242880 ]; then
  mv "$LOG" "${LOG}.1"
fi

exit 0
