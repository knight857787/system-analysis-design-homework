#!/usr/bin/env bash
# 71 恢复：用备份覆盖数据库（会停服务、覆盖数据 —— 高危，执行前会二次确认）
# 用法: bash 71_restore.sh /www/wwwroot/oc-emporiumretai-ms.com/backup/db/store-20261118-023000.db
set -eu

BK_FILE="${1:-}"
DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
DATA="${SITE}/data"

line() { printf '%s\n' "------------------------------------------------------------"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

line
printf '数据库恢复（高危：会覆盖现有数据）\n'
line
[ -n "$BK_FILE" ] || die "用法: bash 71_restore.sh <备份文件.db>"
[ -f "$BK_FILE" ] || die "备份文件不存在: $BK_FILE"

printf '  备份文件 : %s (%s)\n' "$BK_FILE" "$(du -h "$BK_FILE" | awk '{print $1}')"
printf '  将要覆盖 : %s/store.db\n' "$DATA"
printf '  当前数据会先保存为 store.db.pre-restore.<时间戳>\n'
printf '\n  确认继续? 输入 RESTORE 三个字: '
read -r ans
[ "$ans" = "RESTORE" ] || die "已取消"

printf '  完整性校验: '
if python3 - "$BK_FILE" <<'PY'
import sqlite3, sys
c = sqlite3.connect(sys.argv[1])
print('tables=%d' % c.execute("SELECT COUNT(*) FROM sqlite_master WHERE type='table'").fetchone()[0])
PY
then printf '  校验通过\n'; else die "备份文件不是可用的 SQLite 库"; fi

systemctl stop store-assistant || true
[ -f "${DATA}/store.db" ] && cp -a "${DATA}/store.db" "${DATA}/store.db.pre-restore.$(date +%Y%m%d%H%M%S)"
rm -f "${DATA}/store.db-wal" "${DATA}/store.db-shm"
cp -a "$BK_FILE" "${DATA}/store.db"
chown www:www "${DATA}/store.db" 2>/dev/null || true
chmod 640 "${DATA}/store.db"
systemctl start store-assistant
sleep 2
CODE="$(curl -s -o /tmp/_h2.json -w '%{http_code}' http://127.0.0.1:19870/api/health || true)"
printf '  健康检查: HTTP %s %s\n' "$CODE" "$(cat /tmp/_h2.json 2>/dev/null || true)"
[ "$CODE" = "200" ] && printf '  恢复完成。\n' || die "恢复后应用不健康，检查 journalctl -u store-assistant -n 60"
