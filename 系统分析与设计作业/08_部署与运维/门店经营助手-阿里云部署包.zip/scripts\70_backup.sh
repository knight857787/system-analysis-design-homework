#!/usr/bin/env bash
# 70 备份：SQLite 在线备份 + 配置快照 + MySQL 预留库导出（可 cron）
# 用法: bash 70_backup.sh [--keep 30]
# cron: 30 2 * * * /bin/bash /root/oc-deploy/scripts/70_backup.sh --keep 30 >> /var/log/oc-backup.log 2>&1
set -eu

DOMAIN="${DOMAIN:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
DATA="${SITE}/data"
BK="${SITE}/backup"
KEEP=30
while [ $# -gt 0 ]; do
  case "$1" in
    --keep) KEEP="${2:-30}"; shift 2 ;;
    *) shift ;;
  esac
done

TS="$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BK/db" "$BK/conf"

printf '[%s] 开始备份\n' "$(date '+%F %T')"

# 1) SQLite 在线备份（WAL 模式下也一致）
if [ -f "${DATA}/store.db" ]; then
  python3 - "$DATA/store.db" "$BK/db/store-${TS}.db" <<'PY'
import sqlite3, sys
src, dst = sys.argv[1], sys.argv[2]
with sqlite3.connect(src) as s, sqlite3.connect(dst) as d:
    s.backup(d)
print('  sqlite 备份完成 ->', dst)
PY
else
  printf '  [WARN] 找不到 %s\n' "${DATA}/store.db"
fi

# 2) 配置快照（Nginx vhost、systemd unit、证书公钥、MySQL 凭据元信息）
tar -czf "${BK}/conf/conf-${TS}.tar.gz" \
  --warning=no-file-changed \
  "/etc/nginx/conf.d/${DOMAIN}.conf" \
  /etc/nginx/nginx.conf \
  /etc/systemd/system/store-assistant.service \
  /root/.oc_store_mysql.cnf \
  "/etc/nginx/ssl/${DOMAIN}/fullchain.pem" \
  "/www/server/panel/vhost/nginx/${DOMAIN}.conf" 2>/dev/null || true
printf '  配置快照 -> %s\n' "${BK}/conf/conf-${TS}.tar.gz"

# 3) MySQL 预留库导出（如果库里有东西）
DUMP_BIN="/www/server/mysql/bin/mysqldump"
TOOL_CNF="/root/.oc_store_mysql_tool.cnf"
if [ -x "$DUMP_BIN" ] && [ -f "$TOOL_CNF" ]; then
  DB="$(awk -F= '/^database=/{print $2}' /root/.oc_store_mysql.cnf 2>/dev/null || echo oc_store)"
  "$DUMP_BIN" --defaults-extra-file="$TOOL_CNF" --databases "$DB" \
    > "${BK}/db/mysql-${DB}-${TS}.sql" 2>/dev/null && printf '  MySQL 导出 -> mysql-%s-%s.sql\n' "$DB" "$TS" || printf '  [WARN] MySQL 导出跳过\n'
fi

# 4) 保留策略
find "$BK/db"   -type f -name '*.db'  -mtime "+${KEEP}" -delete 2>/dev/null || true
find "$BK/db"   -type f -name '*.sql' -mtime "+${KEEP}" -delete 2>/dev/null || true
find "$BK/conf" -type f -name '*.tar.gz' -mtime "+${KEEP}" -delete 2>/dev/null || true

printf '[%s] 备份完成，当前保留：\n' "$(date '+%F %T')"
ls -lh "$BK/db" 2>/dev/null | tail -n 5 | sed 's/^/  /'
