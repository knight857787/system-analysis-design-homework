#!/usr/bin/env bash
# 30 站点与 Nginx 反代（会改 nginx 配置并 reload —— 高影响操作）
# 用法: bash 30_nginx.sh [域名]
set -eu

DOMAIN="${1:-oc-emporiumretai-ms.com}"
SITE="/www/wwwroot/${DOMAIN}"
VHOST="/www/server/panel/vhost/nginx/${DOMAIN}.conf"
NGINX_BIN="$(command -v nginx || echo /www/server/nginx/sbin/nginx)"
TPL="$(dirname "$0")/../conf/nginx_oc-emporiumretai-ms.conf"

line() { printf '%s\n' "------------------------------------------------------------"; }
step() { printf '\n>> %s\n' "$1"; }
ok()   { printf '  [OK]   %s\n' "$1"; }
warn() { printf '  [WARN] %s\n' "$1"; }
die()  { printf '  [FAIL] %s\n' "$1"; exit 1; }

line
printf '配置站点与反向代理：%s\n' "$DOMAIN"
line

step "1) 环境校验"
[ -x "$NGINX_BIN" ] || die "找不到 nginx 可执行文件（宝塔默认 /www/server/nginx/sbin/nginx）"
"$NGINX_BIN" -v 2>&1 | sed 's/^/  /'
[ -d /www/server/panel/vhost/nginx ] || die "宝塔 vhost 目录不存在"
[ -f "$TPL" ] || die "缺少模板 $TPL"
[ -d "$SITE/app" ] || warn "站点 app 目录不存在（请先跑 20_deploy_app.sh）"

step "2) 证书目录（先建空位，避免 nginx -t 因缺证书失败）"
CERT_DIR="/www/server/panel/vhost/cert/${DOMAIN}"
mkdir -p "$CERT_DIR"
if [ ! -f "${CERT_DIR}/fullchain.pem" ]; then
  warn "尚无证书，先放一份自签名临时证书，保证 nginx -t 能过；申请到正式证书后覆盖即可"
  openssl req -x509 -nodes -newkey rsa:2048 -days 30 \
    -keyout "${CERT_DIR}/privkey.pem" -out "${CERT_DIR}/fullchain.pem" \
    -subj "/CN=${DOMAIN}" >/dev/null 2>&1 || die "openssl 生成自签名证书失败"
  ok "临时自签名证书已生成（浏览器会提示不安全，属预期）"
else
  ok "已存在证书: ${CERT_DIR}/fullchain.pem"
fi

step "3) 站点目录与日志目录"
mkdir -p "$SITE" /www/wwwlogs
if id www >/dev/null 2>&1; then chown -R www:www "$SITE"; chown www:www /www/wwwlogs 2>/dev/null || true; fi
ok "目录就绪"

step "4) 写入 vhost"
if [ -f "$VHOST" ]; then
  cp -a "$VHOST" "${VHOST}.bak.$(date +%Y%m%d%H%M%S)"
  ok "已备份原 vhost"
fi
cp -a "$TPL" "$VHOST"
chmod 644 "$VHOST"
ok "已写入 $VHOST"

step "5) 语法检查"
if "$NGINX_BIN" -t 2>&1 | sed 's/^/  /' | grep -q 'successful'; then
  ok "nginx -t 通过"
else
  printf '  nginx -t 失败，vhost 未生效。回滚命令：\n'
  printf '    cp -a %s.bak.* %s && %s -s reload\n' "$VHOST" "$VHOST" "$NGINX_BIN"
  die "请把上面的报错发我，我按报错修"
fi

step "6) 重载 Nginx"
if systemctl is-active --quiet nginx 2>/dev/null; then
  systemctl reload nginx && ok "systemctl reload nginx"
elif [ -f /etc/init.d/nginx ]; then
  /etc/init.d/nginx reload && ok "init.d reload nginx"
else
  "$NGINX_BIN" -s reload && ok "nginx -s reload"
fi

step "7) 本机自测（走域名解析，若本机 hosts 未指过来会失败，属正常）"
printf '  curl -I http://127.0.0.1/ -H "Host: %s"\n' "$DOMAIN"
curl -s -o /dev/null -w '  HTTP %{http_code}  跳转: %{redirect_url}\n' \
  -H "Host: ${DOMAIN}" "http://127.0.0.1/" || true
printf '  curl -k https://127.0.0.1/api/health -H "Host: %s"\n' "$DOMAIN"
curl -sk -o /tmp/_h.json -w '  HTTP %{http_code}  ' -H "Host: ${DOMAIN}" "https://127.0.0.1/api/health" || true
cat /tmp/_h.json 2>/dev/null || true
printf '\n'

line
printf 'Nginx 就绪。下一步：bash 40_ssl.sh %s（申请正式证书）\n' "$DOMAIN"
